<html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UDAIPUR</title>
<head>
	 <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        
        .logo img {
            width: 50px;
            height: auto;
            vertical-align: middle;
            margin-right: 10px;
        }
        
        nav {
            background-color: #444;
            text-align: center;
            padding: 10px 0;
        }
        
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        
        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
        }
        
     
        
        .intro h2 {
            font-size: 2em;
            margin-bottom: 20px;
        }
		DIV { BORDER-RADIUS:15PX;}
		TD {FONT-FAMILY:"MV Boli";
		COLOR:#333;}
		  </style>

</head>
<body>
<header>
    <div class="logo">
     <a href="index.php">    <img src="logo.png"><br>
        <h2><span style="font-family:'Chiller';">VISITORR</span></h2></a>
    </div>
</header>






<div STYLE="BORDER-RADIUS:1PX">
  <img id="images" src="" WIDTH=100% HEIGHT=80% alt="Image">
  </div>
  <script>
  // JavaScript code to change images
  var images = ['U2.jpg','U3.JPG', 'U4.jpeg','U5.JPG']; // List of image URLs
  var currentIndex = 0;
  var imageElement = document.getElementById('images');

  function changeImage() {
    imageElement.src = images[currentIndex];
    currentIndex = (currentIndex + 1) % images.length; 
    setTimeout(changeImage, 2000); 
  }
  changeImage();
</script>
  <div>

    <div class="container" style="max-width: 100%; margin: 0 auto; background-color: #fff; padding: 2rem; border-radius: 4px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
        <h1 class="title" style="font-size: 2.5rem; margin-bottom: 1rem;">About UDAIPUR</h1>
        <p class="description"  WIDTH=100%style="font-size: 1.1rem; margin-bottom: 1.5rem;">
          Located around the green hills of Aravallis, Udaipur is a charming city, known for its lavish royal residences, picturesque lakes, and magnificent temples. The famous Lake Palace located in the middle of Lake Pichola is a major tourist attraction. The City Palace is considered to be the largest royal complex in the state. Its sprawling complex has numerous palaces, stunning courtyards with artistic gardens, and ornate peacock mosaics. Jagdish Temple, Jagmandir, Vintage Car Museum, and the beautiful man-made lake, Fateh Sagar Lake are a few other popular attractions of the city. Besides lakes and royal buildings, the city is also popular for its bustling streets with shops selling a variety of authentic Rajasthani products.
		  </p>
		 </div>
		 
	<DIV STYLE="BACKGROUND-COLOR:DARKGRAY;">	 
   <h2 class="subtitle" style="font-size: 1.8rem; margin-top: 2rem; margin-bottom: 0.5rem;MARGIN-LEFT:3%;MARGIN-TOP:2%;">Recommended Destinations for You</h2>
   
<div style="overflow-x: auto; white-space: nowrap;MARGIN-LEFT:3%;">
  <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:5%;">
    <img src="PALACE.WEBP"  style="width: 200px; height: 200px; BORDER-RADIUS:8%" >
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">City Palace</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	City Palace in Udaipur is an <BR>
	architectural marvel that stands<BR>
	as a testament to the grandeur and<BR>
	elegance of Rajasthan's royal heritage.<BR>
	Perched on the eastern banks of Lake<BR>
	Pichola, this majestic palace complex is<BR>
	a fusion of Rajput and Mughal <BR>
	architectural styles, adorned with<BR>
	intricately carved balconies, domes,<BR>
	and courtyards.
	</P>
  </div>
   <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="JT.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Jagdish Temple</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	Jagdish Temple, an architectural <BR>
	masterpiece nestled in the heart of<BR>
	Udaipur, Rajasthan, is a sacred haven<BR>
	that epitomizes the city's rich cultural<BR>
	heritage and spiritual fervor. Constructed<BR>
	in the 17th century by Maharana Jagat Singh<BR>
	I, this majestic temple is dedicated to <BR>
	Lord Vishnu, the preserver of the universe,<BR>
	and is renowned for its exquisite <BR>
	craftsmanship and intricate carvings.
	</P>
	</DIV>
	
	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="MP.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Maharana Pratap Memorial</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	The Maharana Pratap Memorial, located in <BR> 
	Udaipur, Rajasthan, is a revered tribute <BR>
	to one of the region's most iconic and heroic<BR>
	figures, Maharana Pratap Singh of Mewar. <BR>
	Perched atop the Moti Magri (Pearl Hill), <BR>
	this memorial offers visitors a poignant <BR>
	glimpse into the life and legacy of this <BR>
	valiant warrior king.. <BR><BR><BR>
	</P></div>
  
  	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="CG.jpg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Crystal Gallery</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	the Crystal Gallery<BR> 
	is a must-visit destination for <BR>
	those seeking a glimpse into the <BR>
	extravagant lifestyle of the erstwhile <BR>
	Maharajas of Udaipur. The gallery showcases<BR>
	an impressive array of crystal items, <BR>
	including furniture, chandeliers, crockery,<BR>
	and decorative pieces, each intricately <BR>
	designed and meticulously crafted.<BR><BR> </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="KW.jpg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Kumbhalgarh Wildlife</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Kumbhalgarh Wildlife Sanctuary,<BR>
	nestled in the rugged terrain of the <Br>
	Aravalli Range in Rajasthan, is a haven<br>
	for nature enthusiasts and wildlife lovers.<BR>
	Spread across vast expanses of dry deciduous<BR>
	forests and rocky hills, this sanctuary <BR>
	offers a diverse ecosystem that supports a<BR>
	wide variety of flora and fauna, making it<BR>
	a prime destination for ecotourism and <BR>
	wildlife safaris.
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="LP.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Lake Palace</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	Lake Palace,<BR>
	nestled like a jewel in the heart of <BR>
	Lake Pichola in Udaipur, Rajasthan, is<BR>
	a mesmerizing architectural marvel that<BR>
	embodies the epitome of luxury and <BR>
	romance. This ethereal palace, also <BR>
	known as the "Jewel of Udaipur," floats<BR>
	serenely on the shimmering waters of <BR>
	the lake, offering a fairy-tale setting<BR>
	that enchants visitors from around the globe.
 <BR>
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="BL.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Badi Lake</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	
Badi Lake, nestled amidst the scenic beauty<BR>
 of Udaipur, Rajasthan, is a tranquil haven<BR>
 that beckons travelers with its serene <BR>
 ambiance and breathtaking vistas. Also <BR>
 known as Badi Talab or the "Big Lake," <BR>
 this man-made reservoir offers a picturesque<BR>
 retreat from the hustle and bustle of city<BR>
 life, inviting visitors to unwind amidst <BR>
 nature's splendor.<BR><BR></P></div>


	</DIV></DIV>
<BR>

  
<H2 STYLE="FONT-FAMILY:ARIALBLACK; MARGIN-LEFT:3%; background-color:WHITE;">
HOTELS IN UDAIPUR
</H2>
<div style="overflow-x: auto; white-space: nowrap; background-color:WHITE; MARGIN-LEFT:3%;" >
<div style="font-family: Arial, sans-serif; font-size: 14px; display: flex; justify-content: space-between;">
     
 <div class="link-container11" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="UH1.AVIF" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Radisson Blu Palace </strong> </P><P>★★★★★</p>
        <p><strong>4.1 GOOD RATING</strong></p>
        <p><strong>₹ 5,694</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer11 = document.querySelector('.link-container11');

linkContainer11.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201405011316509287&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTUDR&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTUDR_Udaipur%7CCTUDR_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=24.59013&lng=73.66745&locusId=CTUDR&locusType=city&msclkid=aa81954efcf9172c29f4f37d7f551524&rank=3&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Udaipur&type=city&viewType=PREMIUM&mtkeys=-7004742942184785417 '
  ,'_blank');
});
</script>

 <div class="link-container12" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="UH2.avif" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>The Ananta </strong> </P><P>★★★★★</p>
        <p><strong>4.3 EXELLENT RATING</strong></p>
        <p><strong>₹ 10,463</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer12 = document.querySelector('.link-container12');

linkContainer12.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201406271058138015&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTUDR&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTUDR_Udaipur%7CCTUDR_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=24.57043&lng=73.62614&locusId=CTUDR&locusType=city&msclkid=aa81954efcf9172c29f4f37d7f551524&rank=6&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Udaipur&type=city&viewType=PREMIUM&mtkeys=-8763246661452852423 '
  ,'_blank');
});
</script>

 <div class="link-container13" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="UH3.avif " style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Fateh Garh Resort</strong> </P><P>★★★★★</p>
        <p><strong>4.6 EXELLENT RATING</strong></p>
        <p><strong>₹ 6,626</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer13 = document.querySelector('.link-container13');

linkContainer13.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=200812011730465958&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTUDR&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTUDR_Udaipur%7CCTUDR_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=24.5682&lng=73.6412&locusId=CTUDR&locusType=city&msclkid=aa81954efcf9172c29f4f37d7f551524&rank=8&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Udaipur&type=city&viewType=LUXE&mtkeys=-1271889835768431554 '
  ,'_blank');
});
</script>

 <div class="link-container14" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="UH4.WEBP" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Aurika</strong> </P><P>★★★★★</p>
        <p><strong>4.5 GOOD RATING</strong></p>
        <p><strong>₹ 7,989</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer14 = document.querySelector('.link-container14');

linkContainer14.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201909041602327140&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTUDR&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTUDR_Udaipur%7CCTUDR_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=24.5745&lng=73.6422&locusId=CTUDR&locusType=city&msclkid=aa81954efcf9172c29f4f37d7f551524&rank=9&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Udaipur&type=city&viewType=LUXE&mtkeys=7454398431681655625 '
  ,'_blank');
});
</script>

 <div class="link-container15" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="UH5.AVIF" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Taj Aravali Resort</strong> </P><P>★★★★★</p>
        <p><strong>4.6 EXELLENT RATING</strong></p>
        <p><strong>₹ 10,900</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer15 = document.querySelector('.link-container15');

linkContainer15.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201811281915067269&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTUDR&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTUDR_Udaipur%7CCTUDR_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=24.57896&lng=73.61183&locusId=CTUDR&locusType=city&msclkid=aa81954efcf9172c29f4f37d7f551524&rank=12&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Udaipur&type=city&viewType=LUXE&mtkeys=6622517646336237957 '
  ,'_blank');
});
</script>

 <div class="link-container16" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="UH6.WEBP" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Shiv Niwas Palace</strong> </P><P>★★★★★</p>
        <p><strong>4.4 GOOD RATING</strong></p>
        <p><strong>₹ 9,184</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer16 = document.querySelector('.link-container16');

linkContainer16.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201409041809296660&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTUDR&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTUDR_Udaipur%7CCTUDR_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=24.57444&lng=73.68425&locusId=CTUDR&locusType=city&msclkid=aa81954efcf9172c29f4f37d7f551524&rank=19&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Udaipur&type=city&viewType=LUXE&mtkeys=4311804241512879011 '
  ,'_blank');
});
</script>



</div>
</DIV>


<div style="background-color: #333; color: #fff; padding: 20px; bottom: 0; width: 100%;">
    <img src="logo.png" alt="Site Logo" style="width: 50px; BORDER-RADIUS:100%;height: auto; margin-right: 10px;">
    
    <span STYLE="margin-LEFT:50%;">Contact: abcd@GMAIL.COM | Phone:123456789</span>
	<BR><BR>
	
	<span STYLE="FONT-FAMILY:CHILLER;">VISITORR.COM</span>
	</DIV>




	<script>
  // JavaScript code to add a scrollbar if the content overflows
  var container = document.querySelector('div');
  if (container.scrollWidth > container.clientWidth) {
    container.style.overflowX = 'scroll';
  }
</script>
</body>
</html>
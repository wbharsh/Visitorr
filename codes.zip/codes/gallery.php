<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gallery</title>
<style>
        body {
            margin: 0;
           
            font-family: Arial, sans-serif;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 2%;
            text-align: center;
        }
        
        .logo img {
            width: 4%;
            height: auto;
            vertical-align: middle;
            margin-right: 1%;
        }
		</style>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: Arial, sans-serif; margin: 0; padding: 0; background-image:url('bg.jpg'); color:white;">
<div>
<header>
    <div class="logo">
        <a href="index.php"><img src="logo.png"><br>
        <h2><span style="font-family:'Chiller';">VISITORR</span></h2></a>
    </div>
</header></div><br>
  <header style="background-color: #333; color: #fff; padding: 1rem; text-align: center;">
    <h1>Gallery</h1>
  </header>
  <main style="padding: 2rem;">
    <div style="display: flex; flex-wrap: wrap; justify-content: center; margin: 0 -1rem;">
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="al.jpg" alt="Image 1" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="bega.webp" alt="Image 2" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="bb.jpeg" alt="Image 3" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="c1.jpg" alt="Image 4" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="chittorgarh.jpg" alt="Image 5" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="c2.jpg" alt="Image 6" style="width: 100%; height: auto;">
      </div>
	  <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="cp.jpeg" alt="Image 1" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="fort.jpg" alt="Image 2" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="f2.jpeg" alt="Image 3" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="desert.jpg" alt="Image 4" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="ganktok.jpg" alt="Image 5" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="goa2.jpg" alt="Image 6" style="width: 100%; height: auto;">
      </div>
	  <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="goa6.jpg" alt="Image 1" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="gt1.jpeg" alt="Image 2" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="gt2.jpg" alt="Image 3" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="i1.jpg" alt="Image 4" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="i3.jpg" alt="Image 5" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="ig.jpg" alt="Image 6" style="width: 100%; height: auto;">
      </div>
	  <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="j1.webp" alt="Image 1" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="i4.webp" alt="Image 2" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="jj2.jpg" alt="Image 3" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="k2.jpeg" alt="Image 4" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="k3.jpeg" alt="Image 5" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="k5.jpg" alt="Image 6" style="width: 100%; height: auto;">
      </div>
	  <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="k13.jpeg" alt="Image 1" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="kasauli.jpg" alt="Image 2" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="kedarnath.jpeg" alt="Image 3" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="kn.jpeg" alt="Image 4" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="kvv.jpeg" alt="Image 5" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="l1.jpg" alt="Image 6" style="width: 100%; height: auto;">
      </div><div style="flex: 1 0 300px; margin: 1rem;">
        <img src="l3.jpeg" alt="Image 1" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="l5.webp" alt="Image 2" style="width: 100%; height: auto;">
      </div>
	   <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="l6.webp" alt="Image 2" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="ld1.jpg" alt="Image 3" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="ld5.jpg" alt="Image 4" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="ld6.jpeg" alt="Image 5" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="m2.jpg" alt="Image 6" style="width: 100%; height: auto;">
      </div>
	   <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="l5.webp" alt="Image 2" style="width: 100%; height: auto;">
      </div>
	  
	  
	  
	  
	  <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="m1.jpeg" alt="Image 3" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="m3.jpg" alt="Image 4" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="m5.jpg" alt="Image 5" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="mahakal.jpeg" alt="Image 6" style="width: 100%; height: auto;">
      </div>
	  <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="mk.jpeg" alt="Image 1" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="nw.jpg" alt="Image 2" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="nm.jpeg" alt="Image 3" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="r4.jpg" alt="Image 4" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="s1.jpg" alt="Image 5" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="s4.jpg" alt="Image 6" style="width: 100%; height: auto;">
      </div>
	  <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="sikkim.jpg" alt="Image 1" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="sn3.jpeg" alt="Image 2" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="sn4.jpeg" alt="Image 3" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="sn5.jpg" alt="Image 4" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="ss2.jpeg" alt="Image 5" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="ss5.jpeg" alt="Image 6" style="width: 100%; height: auto;">
      </div>
	  <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="tso.jpg" alt="Image 1" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="uu2.webp" alt="Image 2" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="uuu3.jpeg" alt="Image 3" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="vk.jpg" alt="Image 4" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="v4.jpg" alt="Image 5" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="v3.jpeg" alt="Image 6" style="width: 100%; height: auto;">
      </div>
	  <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="uuu5.webp" alt="Image 1" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="st4.jpg" alt="Image 2" style="width: 100%; height: auto;">
      </div>
      <div style="flex: 1 0 300px; margin: 1rem;">
        <img src="tv.jpeg" alt="Image 3" style="width: 100%; height: auto;">
      </div>
      
    </div>
  </main>
  <footer style="background-color: #333; color: #fff; padding: 1rem; text-align: center;">
    <p>2024 Gallery</p>
  </footer><br>
	<div style="background-color: #333; color: #fff; padding: 20px; bottom: 0; width: 100%;">
    <img src="logo.png" alt="Site Logo" style="width: 50px; BORDER-RADIUS:100%;height: auto; margin-right: 10px;">
    
    <span STYLE="margin-LEFT:50%;">Contact: abcd@GMAIL.COM | Phone:123456789</span>
	<BR><BR>
	
	<span STYLE="FONT-FAMILY:CHILLER;">VISITORR.COM</span>
	</DIV>
</body>
</html>
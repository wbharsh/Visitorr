<!DOCTYPE html>
<html>
<head>
	<title>About Us - Visitor</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
        body {
            margin: 0;
           
            font-family: Arial, sans-serif;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 2%;
            text-align: center;
        }
        
        .logo img {
            width: 4%;
            height: auto;
            vertical-align: middle;
            margin-right: 1%;
        }
		</style>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: Arial, sans-serif; margin: 0; padding: 0; background-image:url('bg.jpg'); color:white;">
<div><header>
    <div class="logo">
        <img src="logo.png"><br>
        <h2><span style="font-family:'Chiller';">VISITORR</span></h2>
    </div>
</header></div><br>
	<header style="background-color: #333; color: #fff; padding: 1em; text-align: center;">
		<nav>
			<ul style="list-style: none; margin: 0; padding: 0; display: flex; justify-content: space-between;">
				<li><a href="index.php" style="color: #fff; text-decoration: none;">Home</a></li>
				<li><a href="privacy.php" style="color: #fff; text-decoration: none;">Privacy Policy</a></li>
				<li><a href="contact.php" style="color: #fff; text-decoration: none;">Contact Us</a></li>
			</ul>
		</nav>
	</header>
	<main style="display: flex; flex-direction: column; align-items: center; padding: 2em;">
		<h1 style="font-size: 24px; margin-bottom: 10px;">About Us</h1>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Our Mission</h2>
			<p style="margin-bottom: 10px;">At Visitor, our mission is to help travelers discover and book unique and memorable travel experiences. We believe that travel should be accessible to everyone, and we strive to make it easy and affordable for people to explore new places and cultures.</p>
		</section>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Our Story</h2>
			<p style="margin-bottom: 10px;">Visitor was founded in [Insert Year] by [Insert Founder Name(s)], who saw an opportunity to create a platform that would make it easier for travelers to find and book unique accommodations and experiences. With a background in [Insert Relevant Experience], they set out to build a team of passionate travelers and technologists who could create a platform that would revolutionize the way people travel.</p>
		</section>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Our Team</h2>
			<p style="margin-bottom: 10px;">Our team is made up of experienced travelers and technologists who are passionate about making travel more accessible and enjoyable. We come from a variety of backgrounds, including [Insert Relevant Experience], and we are committed to providing our users with the best possible experience.</p>
		</section>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Our Partners</h2>
			<p style="margin-bottom: 10px;">We work with a variety of partners to provide our users with the best possible travel experiences. Our partners include [Insert Partner Names], who share our commitment to making travel accessible and enjoyable for everyone.</p>
		</section>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Contact Us</h2>
			<p style="margin-bottom: 10px;">If you have any questions or concerns, please contact us at[Insert Contact Information]. We would love to hear from you!</p>
		</section>
	</main><br>
	<div style="background-color: #333; color: #fff; padding: 20px; bottom: 0; width: 100%;">
    <img src="logo.png" alt="Site Logo" style="width: 50px; BORDER-RADIUS:100%;height: auto; margin-right: 10px;">
    
    <span STYLE="margin-LEFT:50%;">Contact: abcd@GMAIL.COM | Phone:123456789</span>
	<BR><BR>
	
	<span STYLE="FONT-FAMILY:CHILLER;">VISITORR.COM</span>
	</DIV>
</body>
</html>
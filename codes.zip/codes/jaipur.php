<html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JAIPUR</title>
<head>
	 <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        
        .logo img {
            width: 50px;
            height: auto;
            vertical-align: middle;
            margin-right: 10px;
        }
        
        nav {
            background-color: #444;
            text-align: center;
            padding: 10px 0;
        }
        
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        
        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
        }
        
     
        
        .intro h2 {
            font-size: 2em;
            margin-bottom: 20px;
        }
		DIV { BORDER-RADIUS:15PX;}
		TD {FONT-FAMILY:"MV Boli";
		COLOR:#333;}
		  </style>

</head>
<body>
<header>
    <div class="logo">
        <a href="index.php"> <img src="logo.png"><br>
        <h2><span style="font-family:'Chiller';">VISITORR</span></h2></a>
    </div>
</header>






<div STYLE="BORDER-RADIUS:1PX">
  <img id="images" src="" WIDTH=100% HEIGHT=80% alt="Image">
  </div>
  <script>
  // JavaScript code to change images
  var images = ['jaipur1.webp','jaipur2.jpg','jaipur3.jpg', 'jaipur4.jpg','jaipur5.webp']; // List of image URLs
  var currentIndex = 0;
  var imageElement = document.getElementById('images');

  function changeImage() {
    imageElement.src = images[currentIndex];
    currentIndex = (currentIndex + 1) % images.length; 
    setTimeout(changeImage, 2000); 
  }
  changeImage();
</script>
  <div>

    <div class="container" style="max-width: 100%; margin: 0 auto; background-color: #fff; padding: 2rem; border-radius: 4px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
        <h1 class="title" style="font-size: 2.5rem; margin-bottom: 1rem;">About JAIPUR</h1>
        <p class="description"  WIDTH=100%style="font-size: 1.1rem; margin-bottom: 1.5rem;">
            Jaipur is a regal paradise of culture and legacy, rich with architectural jewels, and is affectionately dubbed "The Pink City" for the pink color of its old structures. City Palace provides you a sense of the opulent lifestyle enjoyed by Jaipur's royal family. The astronomy equipment of the Jantar Mantar observatory, located just next door, brings the wonders of space to Earth.
			</p>
		 </div>
		 
	<DIV STYLE="BACKGROUND-COLOR:DARKGRAY;">	 
   <h2 class="subtitle" style="font-size: 1.8rem; margin-top: 2rem; margin-bottom: 0.5rem;MARGIN-LEFT:3%;MARGIN-TOP:2%;">Recommended Destinations for You</h2>
   
<div style="overflow-x: auto; white-space: nowrap;MARGIN-LEFT:3%;">
  <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:5%;">
    <img src="HAWA-MAHAL.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%" >
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">HAWA MAHAL</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	"Hawa Mahal, or the 'Palace of Winds,<BR>
	' stands as an iconic symbol of Jaipur'<BR>
	s rich architectural heritage. This <BR>
	stunning five-story palace, constructed <BR>
	of red and pink sandstone, features <BR>
	intricate latticework and 953 smallwindows<BR>
	providing both aesthetic appeal and <BR>
	practical ventilation forthe royal women<BR>who
	once observed street festivals..
	</P>
  </div>
   <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="FORT.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Nahargarh Fort</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	"Nahargarh Fort, perched majestically on<BR>
	the rugged Aravalli hills overlooking the<BR>
	bustling city of Jaipur, offers a captivating<BR>
	journey through Rajasthan's royal history. <BR>
	Built in the 18th century by Maharaja Sawai <BR>
	Jai Singh II, this formidable fortress was <BR>
	originally constructed as a defense outpost <BR>
	to protect the city <BR>
	against potential 
	invasions.
	</P>
	</DIV>
	
	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="CP.jpEg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">CITY PALACE</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	City Palace, a majestic complex nestled in the<BR>
	heart of Jaipur, embodies the rich cultural <BR>
	heritage and architectural grandeur of <br>
	Rajasthan.Constructed in the 18th century<br>
	by Maharaja SawaiJai Singh II, the palace <br>
	seamlessly blends Rajput,Mughal, and European<br>
	architectural styles, creatinga captivating <br>
	tapestry of history and opulence.<br><br> </P></div>
  
  	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="f2.jpeg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">JAIGARH FORT</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	Jaigarh Fort, standing tall atop the Aravalli<br>
	hills near Jaipur, is a formidable fortress <br>
	that echoes the valor and grandeur of <br>
	Rajasthan's rich history. Built in the early <br>
	18th century by Maharaja Sawai Jai Singh II,<br>
	this imposing structure served as a strategic <br>
	defense outpost and housed several important<br>
	military installations and storage facilities<br>
	<br>  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="temple.jpg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Birla Mandir</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Birla Mandir, also known as the Laxmi Narayan<br>
	Temple, is a serene haven nestled amidst the<br>
	bustling cityscape of Jaipur. Constructed in<br>
	pristine white marble, this architectural <br>
	marvel stands as a tribute to Lord Vishnu <br>
	and Goddess Laxmi, adorned with intricate <br>
	carvings and delicate sculptures that exude <br>
	divine beauty.<br><br>
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="jaipurr.webp"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;"> Albert Hall Museum</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Albert Hall Museum, a jewel in Jaipur's <br>
	cultural crown, stands as a testament to <br>
	the city's rich heritage and artistic legacy.<br>
	Constructed in the late 19th century, this <br>
	magnificent edifice, adorned with <br>
	Indo-Saracenic architecture, serves as a <br>
	repository of art, history, and culture, <br>
	inviting visitors on a captivating journey <br>
	through time.
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="sm.jpg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Sheesh Mahal</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Sheesh Mahal, or the "Palace of Mirrors," <br>
	is a captivating architectural gem nestled<br>
	within the sprawling Amer Fort complex near<br>
	Jaipur. Constructed in the 16th century, this<br>
	exquisite palace showcases the opulent<br>
	craftsmanship and artistic finesse of Rajasthan'<br>
	s bygone era, offering visitors a glimpse into <br>
	the royal lifestyle of the past.<br><br>
  </P></div>


	</DIV></DIV>
<BR>

  
<H2 STYLE="FONT-FAMILY:ARIALBLACK; MARGIN-LEFT:3%; background-color:WHITE;">
HOTELS IN JAIPUR
</H2>
<div style="overflow-x: auto; white-space: nowrap; background-color:WHITE; MARGIN-LEFT:3%;" >
<div style="font-family: Arial, sans-serif; font-size: 14px; display: flex; justify-content: space-between;">
     
 <div class="link-container11" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="h1.webp" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">3 Star</h3>
        <p><strong>Fort Chandragupt</strong> </P><P>★★★☆☆</p>
        <p><strong>3.6 GOOD RATING</strong></p>
        <p><strong>₹ 1,369</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer11 = document.querySelector('.link-container11');

linkContainer11.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201110111054435329&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTJAI&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTJAI_Jaipur%7CCTJAI_Hotel%7CRSA%7C&country=IN&lat=26.92334&lng=75.80168&locusId=CTJAI&locusType=city&msclkid=9a0db82d40cd1e791867de1f058763b9&rank=50&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Jaipur&type=city&viewType=BUDGET&mtkeys=-7539716366063990211 '
  ,'_blank');
});
</script>

 <div class="link-container12" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="h3.avif" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>The Leela Palace Jaipur</strong> </P><P>★★★★★</p>
        <p><strong>4.7 EXELLENT RATING</strong></p>
        <p><strong>₹ 15,000</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer12 = document.querySelector('.link-container12');

linkContainer12.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201711221909293154&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTJAI&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTJAI_Jaipur%7CCTJAI_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=27.04806&lng=75.90271&locusId=CTJAI&locusType=city&msclkid=9a0db82d40cd1e791867de1f058763b9&rank=3&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Jaipur&type=city&viewType=LUXE&mtkeys=-777195421353557589 '
  ,'_blank');
});
</script>

 <div class="link-container13" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="h2.avif " style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Four Points Sheraton</strong> </P><P>★★★★★</p>
        <p><strong>4.0 GOOD RATING</strong></p>
        <p><strong>₹ 3,333</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer13 = document.querySelector('.link-container13');

linkContainer13.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=200910211248178432&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTJAI&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTJAI_Jaipur%7CCTJAI_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=26.86469&lng=75.79609&locusId=CTJAI&locusType=city&msclkid=9a0db82d40cd1e791867de1f058763b9&rank=1&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Jaipur&type=city&mtkeys=3861402383917596399 '
  ,'_blank');
});
</script>

 <div class="link-container14" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="h4.AVIF" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Radisson Jaipur</strong> </P><P>★★★★★</p>
        <p><strong>4.3 GOOD RATING</strong></p>
        <p><strong>₹ 2,429</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer14 = document.querySelector('.link-container14');

linkContainer14.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=200701211613019770&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTJAI&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTJAI_Jaipur%7CCTJAI_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=26.91968&lng=75.79479&locusId=CTJAI&locusType=city&msclkid=9a0db82d40cd1e791867de1f058763b9&rank=2&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Jaipur&type=city&viewType=PREMIUM&mtkeys=-4651895970377063031 '
  ,'_blank');
});
</script>

 <div class="link-container15" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="h5.AVIF" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Golden Tulip</strong> </P><P>★★★★★</p>
        <p><strong>4.1 GOOD RATING</strong></p>
        <p><strong>₹ 2,481</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer15 = document.querySelector('.link-container15');

linkContainer15.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201403281339452363&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTJAI&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTJAI_Jaipur%7CCTJAI_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=26.91623&lng=75.80524&locusId=CTJAI&locusType=city&msclkid=9a0db82d40cd1e791867de1f058763b9&rank=5&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Jaipur&type=city&mtkeys=2949350333842817536 '
  ,'_blank');
});
</script>

 <div class="link-container16" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="h6.AVIF" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Devi Ratn, Jaipur</strong> </P><P>★★★★★</p>
        <p><strong>4.6 EXELLENT RATING</strong></p>
        <p><strong>₹ 9,000</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer16 = document.querySelector('.link-container16');

linkContainer16.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201107021331089994&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTJAI&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTJAI_Jaipur%7CCTJAI_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=26.91682&lng=75.88065&locusId=CTJAI&locusType=city&msclkid=9a0db82d40cd1e791867de1f058763b9&rank=11&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Jaipur&type=city&viewType=LUXE&mtkeys=2033939459917194802 '
  ,'_blank');
});
</script>



</div>
</DIV>


<div style="background-color: #333; color: #fff; padding: 20px; bottom: 0; width: 100%;">
    <img src="logo.png" alt="Site Logo" style="width: 50px; BORDER-RADIUS:100%;height: auto; margin-right: 10px;">
    
    <span STYLE="margin-LEFT:50%;">Contact: abcd@GMAIL.COM | Phone:123456789</span>
	<BR><BR>
	
	<span STYLE="FONT-FAMILY:CHILLER;">VISITORR.COM</span>
	</DIV>


	<script>
  // JavaScript code to add a scrollbar if the content overflows
  var container = document.querySelector('div');
  if (container.scrollWidth > container.clientWidth) {
    container.style.overflowX = 'scroll';
  }
</script>
</body>
</html>
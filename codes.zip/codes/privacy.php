<!DOCTYPE html>
<html>
<head>
	<title>Privacy Policy - Visitor</title>
	<style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 2%;
            text-align: center;
        }
        
        .logo img {
            width: 4%;
            height: auto;
            vertical-align: middle;
            margin-right: 1%;
        }
		</style>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: Arial, sans-serif; margin: 0; padding: 0; background-image:url('bg.jpg'); color:white;">
<div><header>
    <div class="logo">
        <img src="logo.png"><br>
        <h2><span style="font-family:'Chiller';">VISITORR</span></h2>
    </div>
</header></div><br>
	<header style="background-color: #333; color: #fff; padding: 1em; text-align: center;">
		<nav>
			<ul style="list-style: none; margin: 0; padding: 0; display: flex; justify-content: space-between;">
	<li><a href="index.php" style="color: #fff; text-decoration: none;">Home</a></li>
				<li><a href="about.php" style="color: #fff; text-decoration: none;">About Us</a></li>
				<li><a href="contact.php" style="color: #fff; text-decoration: none;">Contact Us</a></li>
			</ul>
		</nav>
	</header>
	<main style="display: flex; flex-direction: column; align-items: center; padding: 2em;">
		<h1 style="font-size: 24px; margin-bottom: 10px;">Privacy Policy</h1>
		<p style="margin-bottom: 10px;">Last updated: [Insert Date]</p>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Introduction</h2>
			<p style="margin-bottom: 10px;">At Visitor, we are committed to protecting the privacy of our users. This privacy policy explains how we collect, use, and share personal information.</p>
		</section>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Information We Collect</h2>
			<p style="margin-bottom: 10px;">We collect information from you when you visit our website, including:</p>
			<ul style="list-style: disc; margin-left: 20px;">
				<li>Personal information, such as your name, email address, and phone number, which you provide to us when you contact us or sign up for our newsletter.</li>
				<li>Usage information, such as your IP address, browser type, device type, and operating system, which we automatically collect when you access our website.</li>
				<li>Location information, such as your city and country, which we derive from your IP address.</li>
				<li>Feedback and other information that you provide to us, such as your travel preferences and interests.</li>
			</ul>
		</section>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">How We Use Information</h2>
			<p style="margin-bottom: 10px;">We use the information we collect to:</p>
			<ul style="list-style: disc; margin-left: 20px;">
				<li>Improve our website and services, including to personalize your experience and recommend destinations and hotels.</li>
				<li>Provide personalized recommendations</li>
				<li>Send newsletters and promotional emails</li>
			</ul>
		</section>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Sharing Information</h2>
			<p style="margin-bottom: 10px;">We may share the information we collect with third parties for the following purposes:</p>
			<ul style="list-style: disc; margin-left: 20px;">
				<li>MakeMyTrip (for hotel listings)</li>
				<li>Third-party analytics services</li>
			</ul>
		</section>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">User Rights</h2>
			<p style="margin-bottom: 10px;">You have the right to:</p>
			<ul style="list-style: disc; margin-left: 20px;">
			<li>Access your personal information</li>
				<li>Correct any errors in your personal information</li>
				<li>Erase your personal information</li>
				<li>Object to the processing of your personal information</li>
				<li>Export your personal information</li>
			</ul>
		</section>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Security</h2>
			<p style="margin-bottom: 10px;">We take reasonable measures to protect the personal information we collect from loss, theft, misuse, unauthorized access, disclosure, alteration, and destruction.</p>
		</section>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Changes to This Policy</h2>
			<p style="margin-bottom: 10px;">We may update this policy from time to time. We will notify you of any changes by posting the updated policy on this page.</p>
		</section>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Contact Us</h2>
			<p style="margin-bottom: 10px;">If you have any questions or concerns about this policy, please contact us at [privacy@visitorr.com].</p>
		</section>
	</main><br>
	<div style="background-color: #333; color: #fff; padding: 20px; bottom: 0; width: 100%;">
    <img src="logo.png" alt="Site Logo" style="width: 50px; BORDER-RADIUS:100%;height: auto; margin-right: 10px;">
    
    <span STYLE="margin-LEFT:50%;">Contact: abcd@GMAIL.COM | Phone:123456789</span>
	<BR><BR>
	
	<span STYLE="FONT-FAMILY:CHILLER;">VISITORR.COM</span>
	</DIV>
</body>
</html>
<html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GOA</title>
<head>
	 <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        
        .logo img {
            width: 50px;
            height: auto;
            vertical-align: middle;
            margin-right: 10px;
        }
        
        nav {
            background-color: #444;
            text-align: center;
            padding: 10px 0;
        }
        
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        
        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
        }
        
     
        
        .intro h2 {
            font-size: 2em;
            margin-bottom: 20px;
        }
		DIV { BORDER-RADIUS:15PX;}
		TD {FONT-FAMILY:"MV Boli";
		COLOR:#333;}
		  </style>

</head>
<body>
<header>
    <div class="logo">
       <a href="index.php"> <img src="logo.png"><br>
        <h2><span style="font-family:'Chiller';">VISITORR</span></h2></a>
    </div>
</header>






<div STYLE="BORDER-RADIUS:1PX">
  <img id="images" src="" WIDTH=100% HEIGHT=80% alt="Image">
  </div>
  <script>
  // JavaScript code to change images
  var images = ['goa11.webp','goa4.jpg','goa5.jpg', 'goa1.jpg','goa2.jpg','goa3.jpg']; // List of image URLs
  var currentIndex = 0;
  var imageElement = document.getElementById('images');

  function changeImage() {
    imageElement.src = images[currentIndex];
    currentIndex = (currentIndex + 1) % images.length; 
    setTimeout(changeImage, 2000); 
  }
  changeImage();
</script>
  <div>

    <div class="container" style="max-width: 100%; margin: 0 auto; background-color: #fff; padding: 2rem; border-radius: 4px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
        <h1 class="title" style="font-size: 2.5rem; margin-bottom: 1rem;">Goa, India - A Tropical Paradise</h1>
        <p class="description"  WIDTH=100%style="font-size: 1.1rem; margin-bottom: 1.5rem;">
            Goa is known for its stunning beaches, rich culture, and lively nightlife. The state is a perfect blend of Portuguese and Indian cultures with its historic landmarks, mouth-watering cuisine, and exciting water sports.
			Goa, is a tropical paradise known for its stunning beaches, rich culture, and lively nightlife. The state is a perfect blend of Portuguese and Indian cultures with its historic landmarks, mouth-watering cuisine, and exciting water sports. From the buzzing markets of Panaji to the charming streets of Old Goa, the state boasts a unique charm that's hard to resist. Tourists can indulge in adventurous activities like parasailing, windsurfing, and jet skiing or relax on the golden sandy beaches. With a pleasant climate, fascinating architecture, and friendly locals, Goa is the ideal destination for an unforgettable holiday.
        </p>
		 </div>
		 
	<DIV STYLE="BACKGROUND-COLOR:DARKGRAY;">	 
   <h2 class="subtitle" style="font-size: 1.8rem; margin-top: 2rem; margin-bottom: 0.5rem;MARGIN-LEFT:3%;MARGIN-TOP:2%;">Recommended Destinations for You</h2>
   
<div style="overflow-x: auto; white-space: nowrap;MARGIN-LEFT:3%;">
  <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:5%;">
    <img src="BEGA.webp"  style="width: 200px; height: 200px; BORDER-RADIUS:8%" >
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Baga Beach</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Baga beach is one of the most favourites<BR>
	of all Goan beaches. As a tourist, your Goa<BR>
	trip is incomplete if you haven’t been to <BR>
	Baga. There is always something happening<BR>
	thing going on there. In the morning time,<BR>
	the beach is a perfect place to lounge in,<BR>
	take a sunbath and interact with the tourists<BR>
	across the world. Then comes the adventure’s,<BR>
	you can go for some adventurous water sports.
	</P>
  </div>
   <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="CALANGUTE.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Calangute Beach</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Calangute Beach Goa is One of the<BR>
	largest beaches in Goa lovingly<BR>
	called the “Queen of Beaches.” The<BR>
	serenity and beauty make it one of<BR>
	among the top ten beaches in the <BR>
	world and thus a must visit place<BR>
	in Goa. The Calangute beach is big<BR>
	with enough activities to fill your<BR>
	mind. 
	</P>
	</DIV>
	
	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="Casino-Cruise-Goa.jpg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Casino Cruise</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	To do a little out of box thing in<BR>
	Goa, Casino Cruise is the best and<BR>
	essential thing to do. It is a <BR>
	restaurant but with the additional<BR>
	casino features for those who want<BR>
	to experience a Vegas-style <BR>
	entertainment.The cruise is docked<BR>
	on one of the many rivers in Goa and<BR>
	is equipped with exclusive furnishings.
  </P></div>
  
  	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="925775335s.jpg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Mangueshi Temple</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	A major tourist attraction of Goa is<BR>
	Lord Mangueshi Temple, a form of Shiva.<BR>
	The Mangueshi is a great way to escape<BR>
	for those who want to taste the authentic<BR>
	Goan life.  An imposing Nandi statue near<BR>
	the entrance is the main attraction of <BR>
	the temple. Following it, a magnificent<BR>
	seven storied lamp-tower is an added<BR>
	charm of the beautiful temple. 
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="Goa-is-famous-for-its-night-markets.jpg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Anjuna Flea Market</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	The weekly Wednesday Flea markets<BR>
	are glorious and delightful Goan<BR>
	experience, and the Anjuna Flea<BR>
	market is one of the Best Places<BR>
	to visit in Goa. It is a fascinating<BR>
	offset to the beaches and is only <BR>
	in operation from mid-November to<BR>
	April. You can find a variety of<BR>
	goods here at real rates. 
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="Club Cubana Nightclub.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;"> Club Cubana Nightclub</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	It is popularly known as the <BR>
	“Nightclub in the sky.” As the name<BR>
	suggests, the club is located in a<BR>
	remote location on top of the Arpora<BR>
	hill in North Goa. Being remote,still,<BR>
	it is a great attraction for party <BR>
	lovers. A spacious dance floor to <BR>
	groove into the beats entices the <BR>
	people. 
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="Martins-Corner-Website-Images-1.jpg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;"> Martin’s Corner</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	To do a little out of box thing in<BR>
	Yep, that’s true; it’s a celebrity<BR>
	corner, famous in Goa. Ask any <BR>
	tourist where they have dinned in<BR>
	South Goa; they will surely reply,<BR>
	Martin’s Corner. The delicious <BR>
	seafood cooked in Goan Masala is<BR>
	the speciality of Martin’s Corner<BR>
	and not to forget, you might be lucky<BR>
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="kw-110417-A-boat-near-the-Butterfly-Beach-with-the-forest-cover-in-the-background.webp"  style="width: 200px; BORDER-RADIUS:8%; height: 200px;">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Butterfly Beach</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	To do a little out of box thing in<BR>
	The Butterfly beach is one of the<BR>
	Best Places To Visit In Goa. Butterfly<BR>
	beach is a small beach cove that just<BR>
	lies to the north of Palolem beach.<BR>
	The sands of this beach are entirely<BR>
	white, and the water is translucent.<BR>
	There is no access the beach road <BR>
	asthe area is densely forested. 
	</DIV>
	</DIV></DIV>
<BR>

  
<H2 STYLE="FONT-FAMILY:ARIALBLACK; MARGIN-LEFT:3%; background-color:WHITE;">
HOTELS IN GOA
</H2>
<div style="overflow-x: auto; white-space: nowrap; background-color:WHITE; MARGIN-LEFT:3%;" >
<div style="font-family: Arial, sans-serif; font-size: 14px; display: flex; justify-content: space-between;">
     
 <div class="link-container1" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="2.JPG" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">3 Star</h3>
        <p><strong>ibis Styles Goa Calangute</strong> </P><P>★★★☆☆</p>
        <p><strong>4.1 GOOD RATING</strong></p>
        <p><strong>₹ 5,920</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
	<script>  
 const linkContainer = document.querySelector('.link-container1');

linkContainer.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201606272320021734&_uCurrency=INR&checkin=05252024&checkout=05262024&city=CTGOI&cmp=SEO&country=IN&lat=15.54075&lng=73.76276&locusId=CTGOI&locusType=city&modifyDates=true&rank=3&roomStayQualifier=2e0e&searchText=Goa&seoDS=true&seoReq=1714490818727&mtkeys=defaultMtkey',
  '_blank');
});
</script>
    <div class="link-container6" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="12.JPG" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Taj Cidade de Goa Horizon</strong> </P><P>★★★★★</p>
        <p><strong>4.7 EXCELLENT RATING</strong></p>
        <p><strong>₹ 17,999</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
	<script>  
 const linkContainer6 = document.querySelector('.link-container6');

linkContainer6.addEventListener('click', () => {
  window.open('https://www.makemytrip.com', '_blank');
});
</script>
</script>
    <div class="link-container6" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="13.jpg" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">4 Star</h3>
        <p><strong>TajCidade de Goa Horizon</strong> </P><P>★★★★☆</p>
        <p><strong>4.4 EXCELLENT RATING</strong></p>
        <p><strong>₹ 12,000</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
	<script>  
 const linkContainer6 = document.querySelector('.link-container6');

linkContainer6.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=202001281719543603&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTGOI&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTGOI_Goa%7CCTGOI_Hotel%7CRSA%7C&country=IN&lat=15.45719&lng=73.81154&locusId=CTGOI&locusType=city&msclkid=3248c590330e13869bb1a3a274ac98d1&rank=1&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Goa&topHtlId=202001281719543603&type=city&viewType=LUXE&mtkeys=-7083660595057058571 ' 
  , '_blank');
});
</script>


    <div class="link-container3" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="4.JPG" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong></strong>Golden Tulip Goa</P><P>★★★★★</p>
        <p><strong>4.3 EXCELLENT RATING</strong></p>
        <p><strong>₹ 9,399</strong></p>
		<p>CLICK FOR BOOKING</P>
		
    </div>
	
	<script>  
 const linkContainer3 = document.querySelector('.link-container3');

linkContainer3.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201212121355059761&_uCurrency=INR&checkin=05252024&checkout=05262024&city=CTGOI&cmp=SEO&country=IN&lat=15.51139&lng=73.77398&locusId=CTGOI&locusType=city&modifyDates=true&rank=15&roomStayQualifier=2e0e&searchText=Goa&seoDS=true&seoReq=1714490818727&mtkeys=defaultMtkey' ,'_blank');
});
</script>

  
    <div class="link-container4" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="0.JPG" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">3 Star</h3>
        <p><strong>SinQ The Party Hotel</strong> </P><P>★★★☆☆</p>
        <p><strong>3.8 GOOD RATING</strong></p>
        <p><strong>₹ 2,242</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
	<script>  
const linkContainer4 = document.querySelector('.link-container4');

linkContainer4.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201708141704145698&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTGOI&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTGOI_Goa%7CCTGOI_Hotel%7CRSA%7C&country=IN&lat=15.53218&lng=73.76512&locusId=CTGOI&locusType=city&msclkid=3248c590330e13869bb1a3a274ac98d1&rank=1&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Goa&topHtlId=201708141704145698&type=city&viewType=LUXE&mtkeys=9047264471029824458', '_blank');});
</script>


    <div class="link-container4" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="3.JPG" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">3 Star</h3>
        <p><strong>Le Meridien Goa, Calangute</strong> </P><P>★★★☆☆</p>
        <p><strong>4.0 GOOD RATING</strong></p>
        <p><strong>₹ 2,593</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
	<script>  
 const linkContainer4 = document.querySelector('.link-container4');

linkContainer4.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201708141704145698&_uCurrency=INR&checkin=05252024&checkout=05262024&city=CTGOI&cmp=SEO&country=IN&lat=15.53218&lng=73.76512&locusId=CTGOI&locusType=city&modifyDates=true&rank=10&roomStayQualifier=2e0e&searchText=Goa&seoDS=true&seoReq=1714490818727&viewType=LUXE&mtkeys=defaultMtkey', 
  '_blank');
});
</script>

    <div class="link-container5" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="1.JPG" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Elements by Rosetta</strong> </P><P>★★★★★</p>
        <p><strong>4.7 EXCELLENT RATING</strong></p>
        <p><strong>₹ 7,492</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
	<script>  
 const linkContainer5 = document.querySelector('.link-container5');

linkContainer5.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=202310181617186754&_uCurrency=INR&checkin=05252024&checkout=05262024&city=CTGOI&cmp=SEO&country=IN&lat=15.22122&lng=73.94529&locusId=CTGOI&locusType=city&modifyDates=true&rank=19&roomStayQualifier=2e0e&searchText=Goa&seoDS=true&seoReq=1714490818727&viewType=PREMIUM&mtkeys=defaultMtkey
  '_blank');
});
</script>
<div class="link-container2" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="G2.JPG" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">4 Star</h3>
        <p><strong>Estrela Do Mar Beach Resort</strong> </P><P>★★★★☆</p>
        <p><strong>3.8 GOOD RATING</strong></p>
        <p><strong>₹ 4,275</strong></p>
		<p>CLICK FOR BOOKING</P>
		
    </div>
	<script>  
 const linkContainer2 = document.querySelector('.link-container2');

linkContainer2.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=200801081506202871&_uCurrency=INR&checkin=05252024&checkout=05262024&city=CTGOI&cmp=SEO&country=IN&lat=15.55097&lng=73.75539&locusId=CTGOI&locusType=city&modifyDates=true&rank=1&roomStayQualifier=2e0e&searchText=Goa&seoDS=true&seoReq=1714490818727&mtkeys=defaultMtkey', '_blank');
});
</script>



</div>
</DIV>

<div style="background-color: #333; color: #fff; padding: 20px; bottom: 0; width: 100%;">
    <img src="logo.png" alt="Site Logo" style="width: 50px; BORDER-RADIUS:100%;height: auto; margin-right: 10px;">
    
    <span STYLE="margin-LEFT:50%;">Contact: abcd@GMAIL.COM | Phone:123456789</span>
	<BR><BR>
	
	<span STYLE="FONT-FAMILY:CHILLER;">VISITORR.COM</span>
	</DIV>


	<script>
  // JavaScript code to add a scrollbar if the content overflows
  var container = document.querySelector('div');
  if (container.scrollWidth > container.clientWidth) {
    container.style.overflowX = 'scroll';
  }
</script>
</body>
</html>
<html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JAISELMER</title>
<head>
	 <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        
        .logo img {
            width: 50px;
            height: auto;
            vertical-align: middle;
            margin-right: 10px;
        }
        
        nav {
            background-color: #444;
            text-align: center;
            padding: 10px 0;
        }
        
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        
        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
        }
        
     
        
        .intro h2 {
            font-size: 2em;
            margin-bottom: 20px;
        }
		DIV { BORDER-RADIUS:15PX;}
		TD {FONT-FAMILY:"MV Boli";
		COLOR:#333;}
		  </style>

</head>
<body>
<header>
    <div class="logo">
        <a href="index.php"> <img src="logo.png"><br>
        <h2><span style="font-family:'Chiller';">VISITORR</span></h2></a>
    </div>
</header>






<div STYLE="BORDER-RADIUS:1PX">
  <img id="images" src="" WIDTH=100% HEIGHT=80% alt="Image">
  </div>
  <script>
  // JavaScript code to change images
  var images = ['J1.webp','J2.jpg','J3.AVIF', 'j4.jpg','J5.JPG']; // List of image URLs
  var currentIndex = 0;
  var imageElement = document.getElementById('images');

  function changeImage() {
    imageElement.src = images[currentIndex];
    currentIndex = (currentIndex + 1) % images.length; 
    setTimeout(changeImage, 2000); 
  }
  changeImage();
</script>
  <div>

    <div class="container" style="max-width: 100%; margin: 0 auto; background-color: #fff; padding: 2rem; border-radius: 4px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
        <h1 class="title" style="font-size: 2.5rem; margin-bottom: 1rem;">About JAISELMER</h1>
        <p class="description"  WIDTH=100%style="font-size: 1.1rem; margin-bottom: 1.5rem;">
           Jaisalmer is a golden city in the heart of the Thar Desert, where history and adventure await you. Explore the magnificent Jaisalmer Fort, a living museum of Rajasthani culture and architecture, where you can admire the royal palace, the ornate havelis, and the stunning views of the desert. Visit the mysterious ghost town of Kuldhara, where a legend of love and betrayal still haunts the ruins. Experience the thrill of a camel safari, a desert camp, and a starry night under the clear sky. Jaisalmer is a place where you can discover the beauty and mystery of the desert.
		   </p>
		 </div>
		 
	<DIV STYLE="BACKGROUND-COLOR:DARKGRAY;">	 
   <h2 class="subtitle" style="font-size: 1.8rem; margin-top: 2rem; margin-bottom: 0.5rem;MARGIN-LEFT:3%;MARGIN-TOP:2%;">Recommended Destinations for You</h2>
   
<div style="overflow-x: auto; white-space: nowrap;MARGIN-LEFT:3%;">
  <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:5%;">
    <img src="BB.JPEG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%" >
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Bada Bagh</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Bada Bagh, translating to "Big Garden"<BR>
	is a picturesque desert oasis located <BR>
	just outside the enchanting city of <BR>
	Jaisalmer in Rajasthan, India. This <BR>
	historic site, also known as Barabagh,<BR>
	holds immense cultural and architectural<BR>
	significance, making it a must-visit <BR>
	destination for travelers seeking to<BR>
	unravel the mysteries of the desert.
	</P>
  </div>
   <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="JJJ.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Jaisalmer War Museum</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	Jaisalmer War Museum stands as a solemn<BR>
	tribute to the valor, sacrifices, and <BR>
	indomitable spirit of the Indian Armed <BR>
	Forces. Situated in the heart of the <BR>
	historic city of Jaisalmer, Rajasthan,<BR>
	this museum offers visitors a poignant<BR>
	journey through India's military <BR>
	history,particularly focusing on the <BR>
	heroic deeds and sacrifices by soldiers.
	</P>
	</DIV>
	
	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="JJ1.WEBP"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Gadsisar Sagar Lake</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Gadsisar Sagar Lake, a tranquil oasis<BR>
	nestled amidst the golden sands of <BR>
	Jaisalmer, Rajasthan, offers a serene <BR>
	escape for travelers seeking respite <BR>
	from the desert heat. Built in the <BR>
	14th century by Maharaja Gadsi Singh,<BR>
	this man-made reservoir served as a <BR>
	vital water source for the city and its<BR>
	inhabitants. </P></div>
  
  	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="JJ2.jpg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Thar Desert</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	The Thar Desert, <BR>
	spanning across the northwestern region<BR>
	of India and extending into Pakistan, is<BR>
	a mesmerizing landscape of vast, <BR>
	undulating sand dunes, arid plains, and <BR>
	vibrant cultural heritage. the Thar Desert<BR>
	offers a unique and immersive experience <BR>
	for travelers seeking adventure, cultural<BR>
	exploration, and natural beauty. </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="JJ3.jpg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Maharaja's Palace</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	The Maharaja's Palace in Jaisalmer, <BR>
	also known as Jaisalmer Fort Palace <BR>
	Museum, is a majestic architectural wonder<BR>
	perched atop the golden sands of the Thar <BR>
	Desert. This imposing structure, built in <BR>
	the 12th century by Rawal Jaisal, the <BR>
	founder of Jaisalmer, stands as a testament<BR>
	to the city's rich history and cultural <BR>
	heritage.
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="JJ4.JPEG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Tazia Tower</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
Tazia Tower, a striking architectural marvel<BR>
located in the heart of Jaisalmer, Rajasthan,<BR>
 stands as a symbol of the city's rich cultural<BR>
 heritage and artistic finesse. Built in the <BR>
 19th century by Muslim craftsmen, this<BR>
 intricately designed structure serves as<BR>
 a prominent landmark within the vibrant <BR>
 cityscape of Jaisalmer..<BR>
 <BR>
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="JJ5.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Amar Sagar Lake</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
Amar Sagar Lake, nestled in the arid <BR>
landscapes of Jaisalmer, Rajasthan, is a<BR>
tranquil oasis that captivates visitors<BR>
 with its serene beauty and historical <BR>
 significance. Encircled by lush greenery<BR>
 and traditional Rajasthani architecture,<BR>
 this artificial reservoir serves as a <BR>
 refreshing retreat from the desert heat,<BR>
 offering a picturesque setting for 
 relaxation<BR>
  </P></div>


	</DIV></DIV>
<BR>

  
<H2 STYLE="FONT-FAMILY:ARIALBLACK; MARGIN-LEFT:3%; background-color:WHITE;">
HOTELS IN JAISELPUR
</H2>
<div style="overflow-x: auto; white-space: nowrap; background-color:WHITE; MARGIN-LEFT:3%;" >
<div style="font-family: Arial, sans-serif; font-size: 14px; display: flex; justify-content: space-between;">
     
 <div class="link-container11" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="JH1.AVIF" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Marriott Resort </strong> </P><P>★★★★★</p>
        <p><strong>4.5 GOOD RATING</strong></p>
        <p><strong>₹ 6,200</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer11 = document.querySelector('.link-container11');

linkContainer11.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201610272348457391&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTJSA&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTJSA_Jaisalmer%7CCTJSA_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=26.91492&lng=70.89831&locusId=CTJSA&locusType=city&msclkid=2a83198e629b14599eca7fbcf35ad63e&rank=2&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Jaisalmer&type=city&viewType=LUXE&mtkeys=-1290752601566785428 '
  ,'_blank');
});
</script>

 <div class="link-container12" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="JH2.avif" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Gorbandh Palace </strong> </P><P>★★★★★</p>
        <p><strong>4.9 EXELLENT RATING</strong></p>
        <p><strong>₹ 7,250</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer12 = document.querySelector('.link-container12');

linkContainer12.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=20070426084557454&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTJSA&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTJSA_Jaisalmer%7CCTJSA_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=26.91579&lng=70.88857&locusId=CTJSA&locusType=city&msclkid=2a83198e629b14599eca7fbcf35ad63e&rank=3&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Jaisalmer&type=city&mtkeys=5767225310762493554 '
  ,'_blank');
});
</script>

 <div class="link-container13" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="JH3.avif " style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Desert valley resort</strong> </P><P>★★★★★</p>
        <p><strong>4.6 EXELLENT RATING</strong></p>
        <p><strong>₹ 5,223</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer13 = document.querySelector('.link-container13');

linkContainer13.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201912072049416808&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTJSA&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTJSA_Jaisalmer%7CCTJSA_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=26.83673&lng=70.53918&locusId=CTJSA&locusType=city&msclkid=2a83198e629b14599eca7fbcf35ad63e&rank=5&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Jaisalmer&type=city&viewType=PREMIUM&mtkeys=8820710869696929489 '
  ,'_blank');
});
</script>

 <div class="link-container14" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="HJ.AVIF" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Guulab Haveli</strong> </P><P>★★★★★</p>
        <p><strong>4.3 GOOD RATING</strong></p>
        <p><strong>₹ 7,345</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer14 = document.querySelector('.link-container14');

linkContainer14.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=202312021625204331&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTJSA&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTJSA_Jaisalmer%7CCTJSA_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=26.91081&lng=70.91505&locusId=CTJSA&locusType=city&msclkid=2a83198e629b14599eca7fbcf35ad63e&rank=8&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Jaisalmer&type=city&viewType=PREMIUM&mtkeys=-1683530542901979093 '
  ,'_blank');
});
</script>

 <div class="link-container15" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="Jh5.AVIF" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Gobindgarh Jaisalmer</strong> </P><P>★★★★★</p>
        <p><strong>4.3 GOOD RATING</strong></p>
        <p><strong>₹ 1,32,581</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer15 = document.querySelector('.link-container15');

linkContainer15.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=202211231744175828&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTJSA&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTJSA_Jaisalmer%7CCTJSA_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=26.91213&lng=70.77379&locusId=CTJSA&locusType=city&msclkid=2a83198e629b14599eca7fbcf35ad63e&rank=9&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Jaisalmer&type=city&viewType=LUXE&mtkeys=-6031425483176779458 '
  ,'_blank');
});
</script>

 <div class="link-container16" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="JH6.WEBP" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Rupal Residency</strong> </P><P>★★★★★</p>
        <p><strong>4.4 GOOD RATING</strong></p>
        <p><strong>₹ 4,278</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer16 = document.querySelector('.link-container16');

linkContainer16.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=202207231516592486&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTJSA&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTJSA_Jaisalmer%7CCTJSA_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=26.91863&lng=70.90638&locusId=CTJSA&locusType=city&msclkid=2a83198e629b14599eca7fbcf35ad63e&rank=7&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Jaisalmer&type=city&mtkeys=6853076966343651415 '
  ,'_blank');
});
</script>



</div>
</DIV>


<div style="background-color: #333; color: #fff; padding: 20px; bottom: 0; width: 100%;">
    <img src="logo.png" alt="Site Logo" style="width: 50px; BORDER-RADIUS:100%;height: auto; margin-right: 10px;">
    
    <span STYLE="margin-LEFT:50%;">Contact: abcd@GMAIL.COM | Phone:123456789</span>
	<BR><BR>
	
	<span STYLE="FONT-FAMILY:CHILLER;">VISITORR.COM</span>
	</DIV>



	<script>
  // JavaScript code to add a scrollbar if the content overflows
  var container = document.querySelector('div');
  if (container.scrollWidth > container.clientWidth) {
    container.style.overflowX = 'scroll';
  }
</script>
</body>
</html>
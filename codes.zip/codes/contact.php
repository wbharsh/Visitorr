<!DOCTYPE html>
<html>
<head>
	<title>Contact Us - Visitor</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
        body {
            margin: 0;
           
            font-family: Arial, sans-serif;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 2%;
            text-align: center;
        }
        
        .logo img {
            width: 4%;
            height: auto;
            vertical-align: middle;
            margin-right: 1%;
        }
		</style>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: Arial, sans-serif; margin: 0; padding: 0; background-image:url('bg.jpg'); color:white;">
<div><header>
    <div class="logo">
        <img src="logo.png"><br>
        <h2><span style="font-family:'Chiller';">VISITORR</span></h2>
    </div>
</header></div><br>

	<header style="background-color: #333; color: #fff; padding: 1em; text-align: center;">
		<nav>
			<ul style="list-style: none; margin: 0; padding: 0; display: flex; justify-content: space-between;">
				<li><a href="index.php" style="color: #fff; text-decoration: none;">Home</a></li>
				<li><a href="privacy.php" style="color: #fff; text-decoration: none;">Privacy Policy</a></li>
	<li><a href="about.php" style="color: #fff; text-decoration: none;">About Us</a></li>
			</ul>
		</nav>
	</header>
	<main style="display: flex; flex-direction: column; align-items: center; padding: 2em;">
		<h1 style="font-size: 24px; margin-bottom: 10px;">Contact Us</h1>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Get in Touch</h2>
			<p style="margin-bottom: 10px;">If you have any questions or concerns, please contact us using the form below. We will do our best to respond to your inquiry as soon as possible.</p>
			<form style="display: flex; flex-direction: column; align-items: center;">
				<input type="text" name="name" placeholder="Name" style="width: 300px; height: 30px; margin-bottom: 10px; padding: 0 10px; border: 1px solid #ccc; border-radius: 5px;">
				<input type="email" name="email" placeholder="Email" style="width: 300px; height: 30px; margin-bottom: 10px; padding: 0 10px; border: 1px solid #ccc; border-radius: 5px;">
				<textarea name="message" placeholder="Message" style="width: 300px; height: 100px; margin-bottom: 10px; padding: 10px; border: 1px solid #ccc; border-radius: 5px;"></textarea>
				<button type="submit" style="width: 300px; height: 40px; background-color: #333; color: #fff; border: none; border-radius: 5px; cursor: pointer;">Send Message</button>
			</form>
		</section>
		<section style="margin-bottom: 20px;">
			<h2 style="font-size: 18px; margin-top: 10px;">Our Address</h2>
			<p style="margin-bottom: 10px;">Visitorr Tourism<br>
				123 abc.<br>
				indore, India<br>
				<br>
				Phone: +91 1234567890<br>
				Email: [visitorr@gmail.com]</p>
		<div>
<div style="width: 80%; margin: 0 auto; text-align: center;">
  <h1 style="font-size: 2rem; font-weight: bold; margin-bottom: 1rem;">Connect Us</h1>
  <img src="qr.jpeg" alt="QR code" style="width: 100%; max-width: 300px; margin-bottom: 1rem;">
  <div style="display: flex; justify-content: space-around; width: 100%;">
    <a href="https://www.facebook.com/wb.harsh" style="display: block; width: 40px; height: 40px; background-color: #3b5998; margin: 0 5px; display: flex; align-items: center; justify-content: center; transition: background-color 0.3s ease;">
      <img src="fb.jpeg" alt="Facebook" style="width: 20px; height: 20px;">
    </a>
    <a href="https://www.instagram.com/wb.harsh" style="display: block; width: 40px; height: 40px; background-color: #c32aa3; margin: 0 5px; display: flex; align-items: center; justify-content: center; transition: background-color 0.3s ease;">
      <img src="igg.jpeg" alt="Instagram" style="width: 20px; height: 20px;">
    </a>
	 <a href="https://github.com/wbharsh"><img src="github.jpeg" style="height: 30px; margin-left: 10px; margin-top: 3px; transition: background-color 0.5s ease-in-out;" onmouseover="this.style.backgroundColor='yellow'" onmouseout="this.style.backgroundColor=''"></a>
      <a href="https://www.twitter.com/"><img src="twitter.jpeg" style="height: 30px; margin-left: 10px; margin-top: 3px; transition: background-color 0.5s ease-in-out;" onmouseover="this.style.backgroundColor='yellow'" onmouseout="this.style.backgroundColor=''"></a>
      <a href="https://mail.google.com/"><img src="gmail.jpeg" style="height: 30px; margin-left: 10px; margin-top: 3px; transition: background-color 0.5s ease-in-out;" onmouseover="this.style.backgroundColor='yellow'" onmouseout="this.style.backgroundColor=''"></a>
  
  </div>
</div>
	</main><br>
	<div style="background-color: #333; color: #fff; padding: 20px; bottom: 0; width: 100%;">
    <img src="logo.png" alt="Site Logo" style="width: 50px; BORDER-RADIUS:100%;height: auto; margin-right: 10px;">
    
    <span STYLE="margin-LEFT:50%;">Contact: abcd@GMAIL.COM | Phone:123456789</span>
	<BR><BR>
	
	<span STYLE="FONT-FAMILY:CHILLER;">VISITORR.COM</span>
	</DIV>
</body>
</html>
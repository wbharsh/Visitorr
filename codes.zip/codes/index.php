<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VISITORR</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 2%;
            text-align: center;
        }
        
        .logo img {
            width: 4%;
            height: auto;
            vertical-align: middle;
            margin-right: 1%;
        }
        
        nav {
            background-color: #444;
            text-align: center;
            padding: 1% 0;
        }
        
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        
        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
        }
        
     
        
        .intro h2 {
            font-size: 2%;
            margin-bottom: 2%;
        }
		
		TD {FONT-FAMILY:"MV Boli";
		COLOR:#333;}
		
    /* Add some basic styling to make the menu and tables look decent */
    body {
      font-family: Arial, sans-serif;
    }
   .menu {
      list-style: none;
      padding: 0;
      margin: 0;
    }
   .menu li {
      display: inline-block;
      margin-right: 2%;
	  WIDTH=100%
    }
   .menu li a {
      text-decoration: none;
      color: #337ab7;
    }
   .menu li a:hover {
      color: #23527c;
    }
   .table-container {
      display: none;
    }
   .table-container.active {
      display: block;
    }
    table {
      border-collapse: collapse;
      width: 100%;
    }
   
  </style>
    </style>
</head>
<body>
<header>
    <div class="logo">
        <img src="logo.png"><br>
        <h2><span style="font-family:'Chiller';">VISITORR</span></h2>
    </div>
</header>

<nav>
    <ul CLASS="menu" WIDTH=100% STYLE="Font-size:13PX; MARGIN-RIGHT:1%; MARGIN-LEFT:1%" WIDTH=100%>
        <li id="menu-item-1" WIDTH=100%><a href="#">HILL STATIONS</a></li>
        <li id="menu-item-2"><a href="#">BEACH DESTINATION</a></li>
        <li id="menu-item-3"><a href="#">PILGRIMAGE PLACE</a></li>
        <li id="menu-item-4"><a href="#">HISTORICAL PLACES</a></li>
		<li id="menu-item-5"><a href="#">ADVENTURE PLACES</a></li>
		<li id="menu-item-6"><a href="#">NATURE AND WILDLIFE</a></li>
		<li id="menu-item-7"><a href="#">POPULAR CITIES</a></li>
    </ul>
</nav>

<!-- The table containers -->
  <div class="table-container" id="table-container-1">
    <table>
      
      <tr STYLE="BACKGROUND-COLOR:#333">
        <tH HEIGHT=5% WIDTH=5% ><A HREF="SHIMLA.PHP"><IMG SRC="SHIMLAA.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="Kasauli.PHP"><IMG SRC="Kasaulii.PNG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="RISHIKESH.PHP"><IMG SRC="RISHIKESHH.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
       <tH HEIGHT=5% WIDTH=5% > <A HREF="LADAKH.PHP"><IMG SRC="LADAKHH.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="SRINAGER.PHP"><IMG SRC="srinagarr.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        
      </tr>
     
    </table>
  </div>
  <div class="table-container" id="table-container-2">
    <table>
     <tr STYLE="BACKGROUND-COLOR:#333">
        <tH HEIGHT=5% WIDTH=5% ><A HREF="GOA.PHP"><IMG SRC="GOAA.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="KERELA.PHP"><IMG SRC="KERELAA.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="CHENNAI.PHP"><IMG SRC="CHENNAII.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="LAKSYADWEEP.PHP"><IMG SRC="LAKSYADWEEPP.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="GOA.PHP"><IMG SRC="GOAA.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%"></td></A>
      </tr>
    </table>
  </div>
  <div class="table-container" id="table-container-3">
    <table>
      <tr STYLE="BACKGROUND-COLOR:#333">
        <tH HEIGHT=5% WIDTH=5% ><A HREF="UJJAIN.PHP"><IMG SRC="ujjainn.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="VARANASI.PHP"><IMG SRC="varanasii.jpg" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="RISHIKESH.PHP"><IMG SRC="RISHIKESHH.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="CHENNAI.PHP"><IMG SRC="CHENNAII.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="RISHIKESH.PHP"><IMG SRC="kedarnathh.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        
      </tr>
    </table>
  </div>
  
    <div class="table-container" id="table-container-5">
    <table>
      <tr STYLE="BACKGROUND-COLOR:#333">
        <tH HEIGHT=5% WIDTH=5% ><A HREF="JESALMER.PHP"><IMG SRC="jesalmerr.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="Jaipur.PHP"><IMG SRC="jaipurr.jpeg" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="UDAIPUR.PHP"><IMG SRC="UDAIPURR.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="VARANASI.PHP"><IMG SRC="VARANASI.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="BHOPAL.PHP"><IMG SRC="AGRA.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        
      </tr>
    </table>
	</DIV>
  <div class="table-container" id="table-container-4">
    <table>
      
       <tr STYLE="BACKGROUND-COLOR:#333">
        <tH HEIGHT=5% WIDTH=5% ><A HREF="MEGHALAYA.PHP"><IMG SRC="meghalayaa.JPeG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="Kasauli.PHP"><IMG SRC="Kasaulii.PNG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="goa.PHP"><IMG SRC="goaa.jpeg" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="LADAKH.PHP"><IMG SRC="LADAKHH.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="RISHIKESH.PHP"><IMG SRC="RISHIKESHH.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        
      </tr>
    </table>
  

  </div>
  <div class="table-container" id="table-container-6">
    <table>
     
      <tr STYLE="BACKGROUND-COLOR:#333">
        <tH HEIGHT=5% WIDTH=5% ><A HREF="Meghalaya.PHP"><IMG SRC="MeghalayaA.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="KERELA.PHP"><IMG SRC="KERELAA.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="LAKSYADWEEP.PHP"><IMG SRC="LAKSYADWEEPP.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="KASULI.PHP"><IMG SRC="KasauliI.PNG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="SRINAGER.PHP"><IMG SRC="srinagArr.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        
      </tr>
    </table>
  </div>
  <div class="table-container" id="table-container-7">
    <table>
     
       <tr STYLE="BACKGROUND-COLOR:#333">
       <tH HEIGHT=5% WIDTH=5% ><A HREF="INDORE.PHP"><IMG SRC="INDOREE.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%"></td></A>
       <tH HEIGHT=5% WIDTH=5% > <A HREF="GOA.PHP"><IMG SRC="GOAA.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
       <tH HEIGHT=5% WIDTH=5% > <A HREF="BHOPAL.PHP"><IMG SRC="BHOPALL.JPG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% > <A HREF="JAIPUR.PHP"><IMG SRC="JAIPURR.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        <tH HEIGHT=5% WIDTH=5% ><A HREF="BHOPAL.PHP"><IMG SRC="AGRA.JPEG" STYLE="HEIGHT:40%;WIDTH:40%;BORDER-RADIUS:100%;MARGIN-TOP:5%;"></td></A>
        
      </tr>
    </table>
  </div>
  
<script>
    // Get the menu items and table containers
    const menuItems = document.querySelectorAll('.menu li a');
    const tableContainers = document.querySelectorAll('.table-container');

    // Add event listeners to the menu items
    menuItems.forEach((menuItem, index) => {
      menuItem.addEventListener('click', () => {// Hide all table containers
        tableContainers.forEach((tableContainer) => {
          tableContainer.classList.remove('active');
        });

        // Show the corresponding table container
        tableContainers[index].classList.add('active');
      });

      menuItem.addEventListener('mouseover', () => {
        // Hide all table containers
        tableContainers.forEach((tableContainer) => {
          tableContainer.classList.remove('active');
        });

        // Show the corresponding table container
        tableContainers[index].classList.add('active');
      });
    });

    // Add event listener to the document to hide the table container when the user clicks outside it
    document.addEventListener('click', (event) => {
      const target = event.target;
      if (!target.closest('.table-container.active')) {
        tableContainers.forEach((tableContainer) => {
          tableContainer.classList.remove('active');
        });
      }
    });
  </script>

  
<DIV STYLE="background-image: url('background.jpg');padding: 100px;background-position: center;background-size: cover;">
<section class="intro" style="color:black;MARGIN-TOP:20%; MARGIN-RIGHT:75%; BACKGROUND-COLOR:WHITE; BORDER-RADIUS:30PX">
 <DIV style="margin-bottom:2%;MARGIN-TOP:2%; MARGIN-RIGHT:2%;MARGIN-LEFT:2%;">  <h1 STYLE="FONT-FAMILY:Forte;" SIZE=FIXED>“One must travel to learn.”</h2>
    <p>Welcome to VISITORR, your gateway to unforgettable travel experiences! Explore breathtaking destinations, immerse yourself in diverse cultures, and create memories that will last a lifetime.</p>
</DIV></section>
<BR></DIV><CENTER>
<DIV STYLE="BACKGROUND-COLOR:white">
<button id="show-table-button"STYLE="border-radius:40%;MARGIN-TOP:4%;MARGIN-BOTTOM:4%;BACKGROUND-COLOR:BLACK;COLOR:WHITE;" WIDTH=100%>CLICK HERE TO CHECK THE CITIES</button></CENTER></DIV>
<table id="my-table" style="display: none; BACKGROUND-COLOR:SKYBLUE;"WIDTH=100%>
  <thead>

<TR><TH COLSPAN=3 STYLE="FONT-FAMILY:'Elephant'">CITY TO VISIT</TH></TR>
 </thead>
 <tbody>

<tr>
        <td>
           <A HREF="JESALMER.PHP"><img src="JAISALMER.jpg" style="width: 60%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
        <td>
            <A HREF="UDAIPUR.PHP"><img src="UDAIPUR.JPg" style="width:70%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
        <td>
           <a href="jaipur.php"><img src="JAIPUR.jpg" style="width: 80%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px">
        </a></td>
    </tr>
<TR><TH>JAISALMER</TH>
<TH>UDAIPUR</TH>
<TH>JAIPUR</TH>
</TR>

<tr>
        <td><a href='goa.php'>
            <img src="GOA.jpg" style="width: 60%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></a>
        </td>
        <td>
           <A HREF="CHENNAI.PHP"> <img src="CHENNAI.JPg" style="width: 70%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
        <td>
           <A HREF="SHIMLA.PHP"> <img src="SHIMLA.jpEg" style="width: 80%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
    </tr>
<TR><TH> GOA</TH>
<TH>CHENNAI</TH>
<TH>SHIMLA</TH>
</TR>
<tr>
        <td>
            <A HREF="LADAKH.PHP"><img src="LADAKH.jpg" style="width: 60%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
        <td>
            <A HREF="VARANASI.PHP"><img src="VARANASI.JPEg" style="width: 70%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
        <td>
            <A HREF="RISHIKESH.PHP"><img src="RISHIKESH.jpg" style="width: 80%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
    </tr>
<TR><TH>LADAKH</TH>
<TH>VARANASI</TH>
<TH>RISHIKESH</TH>
</TR>
<tr>
        <td>
            <A HREF="UJJAIN.PHP"><img src="UJJAIN.jpg" style="width: 60%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
        <td>
            <A HREF="INDORE.PHP"><img src="INDORE.pNg" style="width: 70%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
        <td>
            <A HREF="BHOPAL.PHP"><img src="BHOPAL.jpeg" style="width: 80%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
    </tr>
<TR><TH>UJJAIN</TH>
<TH>INDORE</TH>
<TH>BHOPAL</TH>
</TR>
<tr>
        <td>
        <A HREF="Kasauli.PHP">   <img src="KASAULI.jpg" style="width: 60%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
        <td>
        <A HREF="GANKTOK.PHP">    <img src="GANKTOK.jpg" style="width: 70%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
        <td>
        <A HREF="MEGHALAYA.PHP">    <img src="MEGHALAYA.jpeg" style="width: 80%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
    </tr>
<TR><TH>Kasauli</TH>
<TH>GANKTOK</TH>
<TH>MEGHALAYA</TH>
</TR>
<tr>
        <td>
          <A HREF="KERELA.PHP">  <img src="KERELA.JPG" style="width: 60%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
        <td>
         <A HREF="LAKSYADWEEP.PHP"> <img src="LAKSYADWEEP.JPG" style="width: 70%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
        <td>
         <A HREF="SRINAGER.PHP">   <img src="srinagar.jpg" style="width: 80%; height: AUTO; display: block; margin: 0 auto; BORDER-RADIUS:50px"></A>
        </td>
    </tr>
<TR><TH>KERELA</TH>
<TH>LAKSYADWEEP</TH>
<TH>SRINAGAR</TH>
</TR>
  </tbody>
</table>




<script>
  // JavaScript code to show the table when the button is clicked
  var button = document.querySelector('#show-table-button');
  var table = document.querySelector('#my-table');
  button.addEventListener('click', function() {
    if (table.style.display === 'none') {
      table.style.display = 'table';
      button.textContent = 'Hide CITY';
    } else {
      table.style.display = 'none';
      button.textContent = 'Show CITY';
    }
  });
</script>

<BR><BR><BR>
<H1 STYLE="FONT-FAMILY:Lucida Bright;">SUGGESTED PLACES TO TRIP!!!</H1>

<div style="overflow-x: auto; white-space: nowrap;">
  <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:5%;">
    <img src="Hawa-mahal.jpg"  style="width: 200px; height: 200px;">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">HAWA-MEHAL</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	The Hawa Mahal is a palacein the city<BR>
	of Jaipur, Rajasthan,India. Built from<BR>
	red and pink sandstone, it is on the <BR>
	edge of the City Palace, Jaipur,<BR>
	and extendsto the Zenana, or women's<BR>
	chambers. 
	</P>
  </div>
   <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="BEGA.webp"  style="width: 200px; height: 200px;">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">BEGA-BEACH</p>
	<P STYLE="FONT-FAMILY:Gabriola;">Baga figures high on tourist<BR>
	itineraries because of its sun and the<BR>
	sea, flea market, nightlife and for <BR>
	its wateringholes and eateries. <BR>
	Baga is hometo some of the biggest <BR>
	hot-spots by night in Goa. 
	</P>
	</DIV>
	
	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="TSO.JPG"  style="width: 200px; height: 200px;">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">TSO-MORIRI</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Tso Moriri or Lake Moriri or <BR>
	"Mountain Lake",<BR>
	is a lake in the Changthang Plateau<BR>
	in Leh district of the union territory of<BR>
	Ladakh in India. It is located approx. 219<BR>
	km from Leh City, capital of Ladakh
  </P></div>
  
  
  
  
  <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="MEGWATER.JPG"  style="width: 200px; height: 200px;">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">KRANG SURI</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Krang Suri Waterfall, nestled <BR>
	amidst the mountains of Meghalaya,<BR>
	is renowned for its breathtaking<BR>
	beauty and tranquil ambiance. <BR>
	Situated near Jowai, this natural<BR>
	wonder captivates visitors with CRYSTAL.<BR>
  </P></div>
  
    <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="DESERT.JPG"  style="width: 200px; height: 200px;">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">DESERT</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Jaisalmer is a major tourist spot<BR>
	located in the northwestern state<BR>
	of Rajasthan in India. It is called<BR>
	the 'golden city' due to its bounteous<BR>
	golden dunes flowing in the Thar Desert.<BR>
	Jaisalmer is adorned with lakes,
  </P></div>
  
  
    <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="Sikkim.jpg"  style="width: 200px; height: 200px;">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">BUDDHA PARK OF RAVANGLA</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	The Buddha Park of Ravangla, also<BR>
	known as Tathagata Tsal, is situated<BR>
	near Ravangla in South Sikkim district<BR>
	of the Indian state of Sikkim. It was<BR>
	constructed between 2006 and 2013, and<BR>
	features a 130-foot-high (40 m) statue.
  </P></div>
  
    <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="CHITTORGARH.JPG"  style="width: 200px; height: 200px;">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">CHITTORGARH-FORT</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	The Chittorgarh <BR>
	(literally Chittor Fort),<BR>
	also known as Chittod Fort,<BR>
	is one of the largest living<BR>
	forts in India. <BR>
	It is a UNESCO World Heritage Site.
  </P></div>
  
  
  <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="taj-mahal.jpg"  style="width: 200px; height: 200px;">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">TAJ-MAHAL</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	The Taj Mahal is an ivory-white<BR>
	marble mausoleum on the south bank<BR>
	of the Yamuna river in the Indian<BR>
	city of Agra. It was commissioned<BR>
	in 1632 by the Mughal emperor, Shah<BR>
	Jahan (reigned from 1628 to 1658), 
  </P></div>
  
  <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="valley-of-flowers.webp"  style="width: 200px; height: 200px;">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">FLOWER VELLY UTTRAKHAND</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	Valley of Flowers National Park is <BR>
	an Indian national park which was <BR>
	established in 1982. It is located in<BR>
	Chamoli in the state of Uttarakhand <BR>
	and is known for its meadows of endemic <BR>
	alpine flowers and the variety of flora. 
  </P></div>
  
    <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="KEDARNATH.jpeg"  style="width: 200px; height: 200px;">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">KEDARNATH</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	Kedarnath is the most remote of the<BR>
	four Chota Char Dham pilgrimage sites.<BR>
	It is located in the Himalayas, about <BR>
	3,583 m (11,755 ft) above sea level <BR>
	near the Chorabari Glacier, which is <BR>
	the source of the Mandakini river. 
  </P></div>
  
  
  <!-- Add more images and descriptions as needed -->
</div>



<script>
  // JavaScript code to add a scrollbar if the content overflows
  var container = document.querySelector('div');
  if (container.scrollWidth > container.clientWidth) {
    container.style.overflowX = 'scroll';
  }
</script>
<div>
<footer style="background-color: #D0DAEE; padding: 20px; width: 100%; box-sizing: border-box;">
  <div style="display: flex; justify-content: space-between; align-items: center;">
    <div>
      <p style="margin: 0;">
	  <table width=80%>
	  <tr><td>
	  
        <a href="gallery.php" style="font-size: 20px; word-spacing: 10px; transition: background-color 0.5s ease-in-out; margin-right: 60px;" onmouseover="this.style.backgroundColor='yellow'" onmouseout="this.style.backgroundColor=''">Gallery</a>
       </td> <td><a href="about.php" style="font-size: 20px; word-spacing: 10px; transition: background-color 0.5s ease-in-out; margin-right: 60px;" onmouseover="this.style.backgroundColor='yellow'" onmouseout="this.style.backgroundColor=''">About Us</a>
       </td> <td> <a href="privacy.php" style="font-size: 20px; word-spacing: 10px; transition: background-color 0.5s ease-in-out;margin-right: 60px;" onmouseover="this.style.backgroundColor='yellow'" onmouseout="this.style.backgroundColor=''">Privacy Policy</a>
      </td> <td><a href="contact.php" style="font-size: 20px; word-spacing: 10px; transition: background-color 0.5s ease-in-out;" onmouseover="this.style.backgroundColor='yellow'" onmouseout="this.style.backgroundColor=''">contact us</a>
   </td>
   </tr>
   </table>
	 </p>
    </div>
    <div>
      <a href="https://github.com/wbharsh"><img src="github.jpeg" style="height: 30px; margin-left: 10px; margin-top: 3px; transition: background-color 0.5s ease-in-out;" onmouseover="this.style.backgroundColor='yellow'" onmouseout="this.style.backgroundColor=''"></a>
      <a href="https://www.twitter.com/"><img src="twitter.jpeg" style="height: 30px; margin-left: 10px; margin-top: 3px; transition: background-color 0.5s ease-in-out;" onmouseover="this.style.backgroundColor='yellow'" onmouseout="this.style.backgroundColor=''"></a>
      <a href="https://mail.google.com/"><img src="gmail.jpeg" style="height: 30px; margin-left: 10px; margin-top: 3px; transition: background-color 0.5s ease-in-out;" onmouseover="this.style.backgroundColor='yellow'" onmouseout="this.style.backgroundColor=''"></a>
    </div>
  </div>
</footer>
</div>

<div style="background-color: #333; color: #fff; padding: 20px; bottom: 0; width: 100%;">
    <img src="logo.png" alt="Site Logo" style="width: 50px; BORDER-RADIUS:100%;height: auto; margin-right: 10px;">
    
    <span STYLE="margin-LEFT:50%;">Contact: abcd@GMAIL.COM | Phone:123456789</span>
	<BR><BR>
	
	<span STYLE="FONT-FAMILY:CHILLER;">VISITORR.COM</span>
	</DIV>
</body>
</html>

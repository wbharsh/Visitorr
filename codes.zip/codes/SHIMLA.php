<html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SHIMLA</title>
<head>
	 <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        
        .logo img {
            width: 50px;
            height: auto;
            vertical-align: middle;
            margin-right: 10px;
        }
        
        nav {
            background-color: #444;
            text-align: center;
            padding: 10px 0;
        }
        
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        
        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
        }
        
     
        
        .intro h2 {
            font-size: 2em;
            margin-bottom: 20px;
        }
		DIV { BORDER-RADIUS:15PX;}
		TD {FONT-FAMILY:"MV Boli";
		COLOR:#333;}
		  </style>

</head>
<body>
<header>
    <div class="logo">
        <a href="index.php"> <img src="logo.png"><br>
        <h2><span style="font-family:'Chiller';">VISITORR</span></h2></a>
    </div>
</header>






<div STYLE="BORDER-RADIUS:1PX">
  <img id="images" src="" WIDTH=100% HEIGHT=80% alt="Image">
  </div>
  <script>
  // JavaScript code to change images
  var images = ['S1.JPG',"ST1.WEBP",'S2.webp','S3.JPG',"ST4.jpg", 'S4.jpg','S5.JPEG']; // List of image URLs
  var currentIndex = 0;
  var imageElement = document.getElementById('images');

  function changeImage() {
    imageElement.src = images[currentIndex];
    currentIndex = (currentIndex + 1) % images.length; 
    setTimeout(changeImage, 2000); 
  }
  changeImage();
</script>
  <div>

    <div class="container" style="max-width: 100%; margin: 0 auto; background-color: #fff; padding: 2rem; border-radius: 4px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
        <h1 class="title" style="font-size: 2.5rem; margin-bottom: 1rem;">About SHIMLA</h1>
        <p class="description"  WIDTH=100%style="font-size: 1.1rem; margin-bottom: 1.5rem;">
           Shimla is the capital of Himachal Pradesh, well known for its beautiful pine and oak forests, gorgeous Himalayan foothills, colonial-style buildings, and handicraft shops. Shimla is one of the best destinations for honeymoons with its snow-covered mountains and lush greenery. Mall Road is the hottest destination for hangouts, shopping, handicrafts, pottery, woolen clothes, wooden products, restaurants, and cafes. The Ridge road is an open space for cultural activities and is the connectivity for all the famous destinations. Viceregal Lodge, the Rashtrapati Niwas, exhibits the ancient articles and photographs giving glimpses of the British rule in India. Jakhu Temple is an ancient temple on Shimla's highest peak, dedicated to Lord Hanuman is a popular tourist spot with vibrant Shivalik hill ranges.
		   </p>
		 </div>
		 
	<DIV STYLE="BACKGROUND-COLOR:DARKGRAY;">	 
   <h2 class="subtitle" style="font-size: 1.8rem; margin-top: 2rem; margin-bottom: 0.5rem;MARGIN-LEFT:3%;MARGIN-TOP:2%;">Recommended Destinations for You</h2>
   
<div style="overflow-x: auto; white-space: nowrap;MARGIN-LEFT:3%;">
  <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:5%;">
    <img src="ST1.WEBP"  style="width: 200px; height: 200px; BORDER-RADIUS:8%" >
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">The Ridge</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	The Ridge road is a large open space,<BR>
	located in the center of Shimla, the <BR>
	capital city of Himachal Pradesh, <BR>
	India. The Ridge is the hub of all <BR>
	cultural activities of Shimla. It is<BR>
	situated  along the Mall Road, which <BR>
	is the  famous shopping center of <BR>
	Shimla. Most major places of Shimla <BR>
	like , Mall Road,Oakover, Kali Bari, <BR>
	etc. Are connected through the ridge.
	</P>
  </div>
   <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="ST.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Kali Bari Mandir</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Kali Bari Mandir is a Hindu temple<BR>
	situated on Bantony Hill, Shimla. <BR>
	The temple is dedicated to fearsome<BR>
	reincarnation of Goddess Kali, known<BR>
	as Shyamala, after which the Shimla <BR>
	city is named. The goddess is believed<BR>
	to have existed near<BR>
	Jakhoo.<BR><BR><BR>
	
	</P>
	</DIV>
	
	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="ST2.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Scandal Point</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Scandal Point serves as a <BR>
	bustling hub of activity, <BR>
	drawing visitors with its <BR>
	panoramic vistas of the surrounding<BR>
	mountains and valleys. Here, travelers <BR>
	can soak in the beauty of Shimla's <BR>
	picturesque landscape while immersing <BR>
	themselves in its rich colonial heritage.<BR><BR><BR>
	
	</P></div>
  
  	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="ST3.WEBP"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">The Forest Sanctuary</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	
	The Forest Sanctuary in Shimla is<BR>
	a verdant haven nestled amidst the<BR>
	majestic Himalayan foothills, <BR>
	offering visitors a serene escape<BR>
	into nature's embrace. Encompassing<BR>
	lush green forests, cascading streams,<BR>
	and diverse flora and fauna, this <BR>
	sanctuary provides a refreshing retreat<BR>
	from the hustle and bustle of city life.<BR><BR>
	</P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="ST4.jpg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Rashtrapati Niwas</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	The Rashtrapati Niwas,<BR>
	formerly known as Viceregal Lodge,<BR>
	is located on the Observatory Hills <BR>
	of Shimla, Himachal Pradesh, India.<BR>
	It was formerly the residence of the<BR>
	British Viceroy of India.<BR><BR><BR><BR><BR>
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="ST5.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Rothney Castle</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	Rothney Castle offers visitors a <BR>
	captivating glimpse into Shimla's <BR>
	colonial past and the fascinating <BR>
	life of Dr. Allan Octavian Hume. <BR>
	Its picturesque location, amidst <BR>
	sprawling gardens and towering pine <BR>
	trees, provides a serene retreat from<BR>
	the hustle and bustle of city life, <BR>
	making it an ideal destination for<BR>
	relaxation and leisure.
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="ST6.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Prantika</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	Prantika serves as an ideal getaway <BR>
	for those seeking to reconnect with <BR>
	nature and rejuvenate their senses. <BR>
	Its verdant forests, meandering trails,<BR>
	and cascading waterfalls provide ample<BR>
	opportunities for hiking, trekking, and<BR>
	wildlife spotting, allowing visitors to <BR>
	immerse themselves in the breathtaking <BR>
	beauty of the Himalayan foothills.<BR><BR>
  </P></div>


	</DIV></DIV>
<BR>

  
<H2 STYLE="FONT-FAMILY:ARIALBLACK; MARGIN-LEFT:3%; background-color:WHITE;">
HOTELS IN SHIMLA
</H2>
<div style="overflow-x: auto; white-space: nowrap; background-color:WHITE; MARGIN-LEFT:3%;" >
<div style="font-family: Arial, sans-serif; font-size: 14px; display: flex; justify-content: space-between;">
     
 <div class="link-container11" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="SH1.AVIF" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Manor Luxury Apartments</strong> </P><P>★★★★★</p>
        <p><strong>4.5 GOOD RATING</strong></p>
        <p><strong>₹ 7,619</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer11 = document.querySelector('.link-container11');

linkContainer11.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=202011231938338189&_uCurrency=INR&checkin=05272024&checkout=05282024&city=CTMSBA&cmp=SEO&country=IN&filterData=STAR_RATING%7C5&lat=31.16742&lng=77.18143&locusId=CTSLV&locusType=city&modifyDates=true&rank=2&roomStayQualifier=2e0e&searchText=Shimla&seoDS=true&seoReq=1714650805452&mtkeys=-392387943423292763 '
  ,'_blank');
});
</script>

 <div class="link-container12" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="SH2.WEBP" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Orchid Shimla </strong> </P><P>★★★★★</p>
        <p><strong>4.5 EXELLENT RATING</strong></p>
        <p><strong>₹ 6,063</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer12 = document.querySelector('.link-container12');

linkContainer12.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=202102240401137697&_uCurrency=INR&checkin=05272024&checkout=05282024&city=CTSLV&cmp=SEO&country=IN&filterData=STAR_RATING%7C5&lat=31.09814&lng=77.20239&locusId=CTSLV&locusType=city&modifyDates=true&rank=3&roomStayQualifier=2e0e&searchText=Shimla&seoDS=true&seoReq=1714650805452&viewType=PREMIUM&mtkeys=2954667787461198439 '
  ,'_blank');
});
</script>

 <div class="link-container13" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="SH3.avif " style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Welcomhotel</strong> </P><P>★★★★★</p>
        <p><strong>4.5 EXELLENT RATING</strong></p>
        <p><strong>₹ 15,300</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer13 = document.querySelector('.link-container13');

linkContainer13.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=202103171718074129&_uCurrency=INR&checkin=05272024&checkout=05282024&city=CTXHI&cmp=SEO&country=IN&filterData=STAR_RATING%7C5&lat=30.99276&lng=77.21559&locusId=CTSLV&locusType=city&modifyDates=true&rank=5&roomStayQualifier=2e0e&searchText=Shimla&seoDS=true&seoReq=1714650805452&viewType=LUXE&mtkeys=-8102954493991676631 '
  ,'_blank');
});
</script>

 <div class="link-container14" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="SH4.AVIF" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Radisson Jass </strong> </P><P>★★★★★</p>
        <p><strong>4.3 GOOD RATING</strong></p>
        <p><strong>₹ 13,500</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer14 = document.querySelector('.link-container14');

linkContainer14.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=200701131553348226&_uCurrency=INR&checkin=05272024&checkout=05282024&city=CTSLV&cmp=SEO&country=IN&filterData=STAR_RATING%7C5&lat=31.11152&lng=77.17735&locusId=CTSLV&locusType=city&modifyDates=true&rank=7&roomStayQualifier=2e0e&searchText=Shimla&seoDS=true&seoReq=1714650805452&viewType=PREMIUM&mtkeys=-5702504845749072199 '
  ,'_blank');
});
</script>

 <div class="link-container15" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="SH5.WEBP" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Deventure Shimla Hills</strong> </P><P>★★★★★</p>
        <p><strong>4.2 GOOD RATING</strong></p>
        <p><strong>₹ 9,175</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer15 = document.querySelector('.link-container15');

linkContainer15.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201704271323427745&_uCurrency=INR&checkin=05272024&checkout=05282024&city=CTKNDG&cmp=SEO&country=IN&filterData=STAR_RATING%7C5&lat=30.98112&lng=77.10761&locusId=CTSLV&locusType=city&modifyDates=true&rank=13&roomStayQualifier=2e0e&searchText=Shimla&seoDS=true&seoReq=1714650805452&mtkeys=1796262179842163972 '
  ,'_blank');
});
</script>

 <div class="link-container16" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="SH6.WEBP" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Wildflower HALL</strong> </P><P>★★★★★</p>
        <p><strong>4.8 EXELLENT RATING</strong></p>
        <p><strong>₹ 34,000</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer16 = document.querySelector('.link-container16');

linkContainer16.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=200701171240402395&_uCurrency=INR&checkin=05272024&checkout=05282024&city=CTMSBA&cmp=SEO&country=IN&filterData=STAR_RATING%7C5&lat=31.11396&lng=77.24767&locusId=CTSLV&locusType=city&modifyDates=true&rank=10&roomStayQualifier=2e0e&searchText=Shimla&seoDS=true&seoReq=1714650805452&viewType=LUXE&mtkeys=-1051508385637865975 '
  ,'_blank');
});
</script>



</div>
</DIV>


<div style="background-color: #333; color: #fff; padding: 20px; bottom: 0; width: 100%;">
    <img src="logo.png" alt="Site Logo" style="width: 50px; BORDER-RADIUS:100%;height: auto; margin-right: 10px;">
    
    <span STYLE="margin-LEFT:50%;">Contact: abcd@GMAIL.COM | Phone:123456789</span>
	<BR><BR>
	
	<span STYLE="FONT-FAMILY:CHILLER;">VISITORR.COM</span>
	</DIV>




	<script>
  // JavaScript code to add a scrollbar if the content overflows
  var container = document.querySelector('div');
  if (container.scrollWidth > container.clientWidth) {
    container.style.overflowX = 'scroll';
  }
</script>
</body>
</html>
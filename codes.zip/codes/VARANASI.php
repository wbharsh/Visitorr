<html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VARANASI</title>
<head>
	 <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        
        .logo img {
            width: 50px;
            height: auto;
            vertical-align: middle;
            margin-right: 10px;
        }
        
        nav {
            background-color: #444;
            text-align: center;
            padding: 10px 0;
        }
        
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        
        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
        }
        
     
        
        .intro h2 {
            font-size: 2em;
            margin-bottom: 20px;
        }
		DIV { BORDER-RADIUS:15PX;}
		TD {FONT-FAMILY:"MV Boli";
		COLOR:#333;}
		  </style>

</head>
<body>
<header>
    <div class="logo">
     <a href="index.php">    <img src="logo.png"><br>
        <h2><span style="font-family:'Chiller';">VISITORR</span></h2></a>
    </div>
</header>






<div STYLE="BORDER-RADIUS:1PX">
  <img id="images" src="" WIDTH=100% HEIGHT=80% alt="Image">
  </div>
  <script>
  // JavaScript code to change images
  var images = ['V2.webp','V1.jpg', 'V3.jpeg','V4.JPG']; // List of image URLs
  var currentIndex = 0;
  var imageElement = document.getElementById('images');

  function changeImage() {
    imageElement.src = images[currentIndex];
    currentIndex = (currentIndex + 1) % images.length; 
    setTimeout(changeImage, 2000); 
  }
  changeImage();
</script>
  <div>

    <div class="container" style="max-width: 100%; margin: 0 auto; background-color: #fff; padding: 2rem; border-radius: 4px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
        <h1 class="title" style="font-size: 2.5rem; margin-bottom: 1rem;">About VARANASI</h1>
        <p class="description"  WIDTH=100%style="font-size: 1.1rem; margin-bottom: 1.5rem;">
         Varanasi is regarded as a sacred city in India by Hindus, Buddhists, and Jains since it is a place of pilgrimage for these devotees. It is also known as the City of Temples where it features a serene and tranquil atmosphere perfect for worship.
   </p>
		 </div>
		 
	<DIV STYLE="BACKGROUND-COLOR:DARKGRAY;">	 
   <h2 class="subtitle" style="font-size: 1.8rem; margin-top: 2rem; margin-bottom: 0.5rem;MARGIN-LEFT:3%;MARGIN-TOP:2%;">Recommended Destinations for You</h2>
   
<div style="overflow-x: auto; white-space: nowrap;MARGIN-LEFT:3%;">
  <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:5%;">
    <img src="KV.JPEG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%" >
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Shri Kashi Vishwanath Mandir</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Kashi Vishwanath Temple is one<BR>
	of the most famous Hindu temples<BR>
	dedicated to Lord Shiva. It is <BR>
	located in Vishwanath Gali of Varanasi,<BR>
	Uttar Pradesh in India.
	</P>
  </div>
   <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="VG.JPEG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Assi Ghat</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	Assi Ghat is the southernmost<BR>
	ghat in Varanasi. To most visitors<BR>
	to Varanasi, it is known for being<BR>
	a place where long-term foreign <BR>
	students,  and tourists live.
	
	</P>
	</DIV>
	
	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="TV.JPEG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Thai Temple
</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	The Thai Temple, also known as the <BR>
	Hinayana Buddha temple, was built by<BR>
	Thai dignitaries in 1933 and is known<BR>
	for its Thai architectural designs. <BR><BR>
	
	</P></div>
  
  	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="VM.jpg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Ratneshwar Mahadev Temple</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Ratneshwar Mahadev Mandir<BR>
	is one of the most<BR>
	photographed temples in <BR>
	the holy city of Varanasi <BR>
	in Uttar Pradesh, India.
	. </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="MK.jpEg"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">MANIKARNIKA GHAT</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Manikarnika Ghat <BR>
	(Hindi: मणिकर्णिका घाट) is one of <BR>
	the holiest[1] cremation grounds <BR>
	among the sacred riverfronts (ghats),<BR>
	located on the banks of River Ganga
  </P></div>



	</DIV></DIV>
<BR>

  
<H2 STYLE="FONT-FAMILY:ARIALBLACK; MARGIN-LEFT:3%; background-color:WHITE;">
HOTELS IN VARANASI
</H2>
<div style="overflow-x: auto; white-space: nowrap; background-color:WHITE; MARGIN-LEFT:3%;" >
<div style="font-family: Arial, sans-serif; font-size: 14px; display: flex; justify-content: space-between;">
     
 <div class="link-container11" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="va1.AVIF" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Hotel Madin </strong> </P><P>★★★★★</p>
        <p><strong>4.3 GOOD RATING</strong></p>
        <p><strong>₹ 10,545</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer11 = document.querySelector('.link-container11');

linkContainer11.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201608231653085625&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTVNS&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTVNS_Varanasi%7CCTVNS_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=25.33724&lng=82.97896&locusId=CTVNS&locusType=city&msclkid=a55253a4eb531baf049235e48ba3dba2&rank=1&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Varanasi&type=city&viewType=PREMIUM&mtkeys=-5702131674823465198 '
  ,'_blank');
});
</script>

 <div class="link-container12" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="va2.avif" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Rivatas By Ideal </strong> </P><P>★★★★★</p>
        <p><strong>4.1 EXELLENT RATING</strong></p>
        <p><strong>₹ 13,020</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer12 = document.querySelector('.link-container12');

linkContainer12.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201301181122262890&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTVNS&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTVNS_Varanasi%7CCTVNS_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=25.33785&lng=82.9796&locusId=CTVNS&locusType=city&msclkid=a55253a4eb531baf049235e48ba3dba2&rank=2&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Varanasi&type=city&viewType=PREMIUM&mtkeys=4899695154937062112 '
  ,'_blank');
});
</script>

 <div class="link-container13" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="va3.webp " style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Radisson Hotel Varanasi</strong> </P><P>★★★★★</p>
        <p><strong>4.0 EXELLENT RATING</strong></p>
        <p><strong>₹ 7,560</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer13 = document.querySelector('.link-container13');

linkContainer13.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=200701211643287246&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTVNS&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTVNS_Varanasi%7CCTVNS_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=25.33849&lng=82.98077&locusId=CTVNS&locusType=city&msclkid=a55253a4eb531baf049235e48ba3dba2&rank=3&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Varanasi&type=city&viewType=PREMIUM&mtkeys=4017439494862832091 '
  ,'_blank');
});
</script>

 <div class="link-container14" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="va4.AVIF" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>BrijRama Palace, Varanasi</strong> </P><P>★★★★★</p>
        <p><strong>4.5 GOOD RATING</strong></p>
        <p><strong>₹ 24,149</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer14 = document.querySelector('.link-container14');

linkContainer14.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=20151201131439256&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTVNS&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTVNS_Varanasi%7CCTVNS_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=25.30525&lng=83.00927&locusId=CTVNS&locusType=city&msclkid=a55253a4eb531baf049235e48ba3dba2&rank=4&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Varanasi&type=city&viewType=LUXE&mtkeys=-4691615617811152653 '
  ,'_blank');
});
</script>

 <div class="link-container15" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="va5.webp" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Taj Ganges</strong> </P><P>★★★★★</p>
        <p><strong>4.6 GOOD RATING</strong></p>
        <p><strong>₹ 14,500</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer15 = document.querySelector('.link-container15');

linkContainer15.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=200706181821376815&_uCurrency=INR&checkin=date_2&checkout=date_3&city=CTVNS&cmp=SEM%7CD%7CDH%7CB%7CDestination%7CDH_Destination_CTVNS_Varanasi%7CCTVNS_Hotel%7CRSA%7C&country=IN&filterData=STAR_RATING%7C5&lat=25.3361&lng=82.98418&locusId=CTVNS&locusType=city&msclkid=a55253a4eb531baf049235e48ba3dba2&rank=6&reference=hotel&regionNearByExp=3&roomStayQualifier=1e0e&searchText=Varanasi&type=city&viewType=PREMIUM&mtkeys=-1965893616854136135 '
  ,'_blank');
});
</script>

</div>
</DIV>


<div style="background-color: #333; color: #fff; padding: 20px; bottom: 0; width: 100%;">
    <img src="logo.png" alt="Site Logo" style="width: 50px; BORDER-RADIUS:100%;height: auto; margin-right: 10px;">
    
    <span STYLE="margin-LEFT:50%;">Contact: abcd@GMAIL.COM | Phone:123456789</span>
	<BR><BR>
	
	<span STYLE="FONT-FAMILY:CHILLER;">VISITORR.COM</span>
	</DIV>



	<script>
  // JavaScript code to add a scrollbar if the content overflows
  var container = document.querySelector('div');
  if (container.scrollWidth > container.clientWidth) {
    container.style.overflowX = 'scroll';
  }
</script>
</body>
</html>
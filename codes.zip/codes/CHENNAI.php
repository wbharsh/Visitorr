<html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CHENNAI</title>
<head>
	 <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        
        .logo img {
            width: 50px;
            height: auto;
            vertical-align: middle;
            margin-right: 10px;
        }
        
        nav {
            background-color: #444;
            text-align: center;
            padding: 10px 0;
        }
        
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        
        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
        }
        
     
        
        .intro h2 {
            font-size: 2em;
            margin-bottom: 20px;
        }
		DIV { BORDER-RADIUS:15PX;}
		TD {FONT-FAMILY:"MV Boli";
		COLOR:#333;}
		  </style>

</head>
<body>
<header>
    <div class="logo">
       <a href="index.php">  <img src="logo.png"><br>
        <h2><span style="font-family:'Chiller';">VISITORR</span></h2></a>
    </div>
</header>






<div STYLE="BORDER-RADIUS:1PX">
  <img id="images" src="" WIDTH=100% HEIGHT=80% alt="Image">
  </div>
  <script>
  // JavaScript code to change images
  var images = ['c1.jpg','c2.jpg','c3.jpg', 'c4.jpg','c5.JPG']; // List of image URLs
  var currentIndex = 0;
  var imageElement = document.getElementById('images');

  function changeImage() {
    imageElement.src = images[currentIndex];
    currentIndex = (currentIndex + 1) % images.length; 
    setTimeout(changeImage, 2000); 
  }
  changeImage();
</script>
  <div>

    <div class="container" style="max-width: 100%; margin: 0 auto; background-color: #fff; padding: 2rem; border-radius: 4px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
        <h1 class="title" style="font-size: 2.5rem; margin-bottom: 1rem;">About CHENNAI</h1>
        <p class="description"  WIDTH=100%style="font-size: 1.1rem; margin-bottom: 1.5rem;">
          The capital city of Tamil Nadu, Chennai is well known for its cultural and historic sites. Earlier known as Madras, the city is the economic hub of the country. The city features many Hindu temples, churches, and great museums. Chennai has everything from its white-sand beaches to mouth-watering seafood. Major attractions include Marina Beach, Government Museum Chennai, and Santhome Cathedral Basilica among others.
		   </p>
		 </div>
		 
	<DIV STYLE="BACKGROUND-COLOR:DARKGRAY;">	 
   <h2 class="subtitle" style="font-size: 1.8rem; margin-top: 2rem; margin-bottom: 0.5rem;MARGIN-LEFT:3%;MARGIN-TOP:2%;">Recommended Destinations for You</h2>
   
<div style="overflow-x: auto; white-space: nowrap;MARGIN-LEFT:3%;">
  <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:5%;">
    <img src="CP1.JPEG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%" >
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Fort St. George</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Fort St. George stands as a testament to<BR>
	the British colonial legacy in the heart<BR>
	of Chennai, India. Constructed in 1644 by<BR>
	the British East India Company, this <BR>
	fortification emerged as the first English<BR>
	fortress in India, laying the foundation<BR>
	for what would eventually become the modern<BR>
	city of Chennai. 
	</P>
  </div>
   <div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="MB.JPEG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Marina Beach</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	Marina Beach<BR>
	is a natural urban beach in Chennai,<BR>
	Tamil Nadu, India, along the Bay of <BR>
	Bengal. The beach runs from near Fort St.<BR><BR><BR><BR><BR>
	</P>
	</DIV>
	
	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="CT.WEBP"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Parthasarathy Swamy Temple</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	The Parthasarathy Temple<BR>
	is an 6th-century Hindu <BR>
	Vaishnavite temple dedicated<BR>
	to Vishnu, located at Thiruvallikeni,<BR>
	Chennai, India. <BR>
	<BR>
	<BR><BR></P></div>
  
  	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="CC.WEBP"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">San Thome Basilica</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	San Thome Church,<BR>
	is known as <BR>
	St. Thomas Cathedral Basilica<BR>
	and National Shrine of Saint Thomas,<BR>
	is a Roman Catholic minor basilica <BR>
	in Santhome, in the city of Chennai,<BR>
	India. <BR><BR></P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="CC2.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Semmozhi Poonga</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	Semmozhi Poonga<BR>
	(literally translated to <BR>
	"Classical Language Park") is a <BR>
	botanical garden in Chennai set up<BR>
	jointly by the Horticulture and <BR>
	Agricultural Engineering department<BR>
	of the Government of Tamil Nadu. The<BR>
	garden was opened on 24 Nov 2010 and
	
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="CC3.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Muttukadu Lake</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	Muttukadu Lake is a picturesque <Br>
	backwater located in the outskirts<BR>
	of Chennai, India. It is a popular<BR>
	tourist destination known for its <BR>
	scenic beauty and serene environment.<BR>
	The lake is surrounded by lush green <BR>
	vegetation and offers a perfect escape <BR>
	from the hustle and bustle of city life.
 <BR>
  </P></div>


	<div style="display: inline-block; margin-right: 10px;BORDER-RADIUS:15%;">
    <img src="CC4.JPG"  style="width: 200px; height: 200px; BORDER-RADIUS:8%">
    <p style="margin-top: 5px; FONT-FAMILY:FORTE;">Vgp Snow Kingdom</p>
	<P STYLE="FONT-FAMILY:Gabriola;">
	
	We’re Snow Kingdom - India’s best<BR>
	and biggest snow theme park, <BR>
	envisioned by a creative, passionate <BR>
	and fun-loving team. We’ve put our heart<BR>
	and soul into making three of the finest<BR>
	theme parks in not just the country, but<BR>
	the entire continent. <BR><BR>
  </P></div>


	</DIV></DIV>
<BR>

  
<H2 STYLE="FONT-FAMILY:ARIALBLACK; MARGIN-LEFT:3%; background-color:WHITE;">
HOTELS IN JAISELPUR
</H2>
<div style="overflow-x: auto; white-space: nowrap; background-color:WHITE; MARGIN-LEFT:3%;" >
<div style="font-family: Arial, sans-serif; font-size: 14px; display: flex; justify-content: space-between;">
     
 <div class="link-container11" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="CH1.JPG" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>THE PARK</strong> </P><P>★★★★★</p>
        <p><strong>3.7 GOOD RATING</strong></p>
        <p><strong>₹ 5,515</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer11 = document.querySelector('.link-container11');

linkContainer11.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=200704121547134827&_uCurrency=INR&checkin=05302024&checkout=05312024&city=CTMAA&cmp=SEO&country=IN&filterData=STAR_RATING%7C5&lat=13.05308&lng=80.25022&locusId=CTMAA&locusType=city&modifyDates=true&rank=1&roomStayQualifier=2e0e&searchText=Chennai&seoDS=true&seoReq=1714853326313&viewType=PREMIUM&mtkeys=-2355448270059726555 '
  ,'_blank');
});
</script>

 <div class="link-container12" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="CH2.JPEG" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Ramada Plaza by Wyndham</strong> </P><P>★★★★★</p>
        <p><strong>4.5 EXELLENT RATING</strong></p>
        <p><strong>₹ 7,838</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer12 = document.querySelector('.link-container12');

linkContainer12.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201707131836443674&_uCurrency=INR&checkin=05302024&checkout=05312024&city=CTMAA&cmp=SEO&country=IN&filterData=STAR_RATING%7C5&lat=13.01211&lng=80.22243&locusId=CTMAA&locusType=city&modifyDates=true&rank=5&roomStayQualifier=2e0e&searchText=Chennai&seoDS=true&seoReq=1714853326313&viewType=PREMIUM&mtkeys=-2331062377873741333 '
  ,'_blank');
});
</script>

 <div class="link-container13" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="CH3.JPEG " style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>The Leela Palace</strong> </P><P>★★★★★</p>
        <p><strong>4.5 EXELLENT RATING</strong></p>
        <p><strong>₹ 14,875</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer13 = document.querySelector('.link-container13');

linkContainer13.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201206151823472024&_uCurrency=INR&checkin=05302024&checkout=05312024&city=CTMAA&cmp=SEO&country=IN&filterData=STAR_RATING%7C5&lat=13.01709&lng=80.27389&locusId=CTMAA&locusType=city&modifyDates=true&rank=7&roomStayQualifier=2e0e&searchText=Chennai&seoDS=true&seoReq=1714853326313&viewType=LUXE&mtkeys=1971290199544107425 '
  ,'_blank');
});
</script>

 <div class="link-container14" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="CH4.JPEG" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Taj Coromandel</strong> </P><P>★★★★★</p>
        <p><strong>4.6 EXELLENT RATING</strong></p>
        <p><strong>₹ 12,400</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer14 = document.querySelector('.link-container14');

linkContainer14.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=200901081302057726&_uCurrency=INR&checkin=05302024&checkout=05312024&city=CTMAA&cmp=SEO&country=IN&filterData=STAR_RATING%7C5&lat=13.05814&lng=80.24734&locusId=CTMAA&locusType=city&modifyDates=true&rank=11&roomStayQualifier=2e0e&searchText=Chennai&seoDS=true&seoReq=1714853326313&viewType=LUXE&mtkeys=-9069726909409570823 '
  ,'_blank');
});
</script>

 <div class="link-container15" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="CH5.JPEG" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>The Accord Metropolitan</strong> </P><P>★★★★★</p>
        <p><strong>4.1 GOOD RATING</strong></p>
        <p><strong>₹ 7,275</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer15 = document.querySelector('.link-container15');

linkContainer15.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=200704172023293012&_uCurrency=INR&checkin=05302024&checkout=05312024&city=CTMAA&cmp=SEO&country=IN&filterData=STAR_RATING%7C5&lat=13.04603&lng=80.24252&locusId=CTMAA&locusType=city&modifyDates=true&rank=18&roomStayQualifier=2e0e&searchText=Chennai&seoDS=true&seoReq=1714853326313&viewType=PREMIUM&mtkeys=3893432281607975088 '
  ,'_blank');
});
</script>

 <div class="link-container16" style="flex: 1; border: 1px solid #ddd; padding: 10px; margin-right: 20px;">
        <img src="CH6.JPEG" alt="5-star hotel" style="width: 100%;">
        <h3 style="color: #444; margin-bottom: 10px;">5 Star</h3>
        <p><strong>Vivanta Chennai, IT Expressway</strong> </P><P>★★★★★</p>
        <p><strong>4.4 GOOD RATING</strong></p>
        <p><strong>₹ 5,750</strong></p>
		<p>CLICK FOR BOOKING</P>
    </div>
<script>  
 const linkContainer16 = document.querySelector('.link-container16');

linkContainer16.addEventListener('click', () => {
  window.open('https://www.makemytrip.com/hotels/hotel-details/?hotelId=201306101502582518&_uCurrency=INR&checkin=05302024&checkout=05312024&city=CTMAA&cmp=SEO&country=IN&filterData=STAR_RATING%7C5&lat=12.90554&lng=80.22775&locusId=CTMAA&locusType=city&modifyDates=true&rank=20&roomStayQualifier=2e0e&searchText=Chennai&seoDS=true&seoReq=1714853326313&mtkeys=-7912318659927230725 '
  ,'_blank');
});
</script>



</div>
</DIV>


<div style="background-color: #333; color: #fff; padding: 20px; bottom: 0; width: 100%;">
    <img src="logo.png" alt="Site Logo" style="width: 50px; BORDER-RADIUS:100%;height: auto; margin-right: 10px;">
    
    <span STYLE="margin-LEFT:50%;">Contact: abcd@GMAIL.COM | Phone:123456789</span>
	<BR><BR>
	
	<span STYLE="FONT-FAMILY:CHILLER;">VISITORR.COM</span>
	</DIV>



	<script>
  // JavaScript code to add a scrollbar if the content overflows
  var container = document.querySelector('div');
  if (container.scrollWidth > container.clientWidth) {
    container.style.overflowX = 'scroll';
  }
</script>
</body>
</html>